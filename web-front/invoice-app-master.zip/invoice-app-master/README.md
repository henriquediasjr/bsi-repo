<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

# How to start project

This project was started using the Laravel [Breeze](https://laravel.com/docs/10.x/starter-kits#laravel-breeze) boostrap.

> Required: PHP 8.2 installed with xml, mbstring and curl extensions;
> NodeJS, Laravel CLI, Symfony CLI and Composer installed;
> Docker-desktop installed (if you are using Windows, it's recommended to use Ubuntu distro).

> Obs: Laravel Sail is an easier way of starting your Laravel project using Docker.


## Running
1. Configure your .env file based on the .env-example file.
2. Open the terminal and run `composer install`.
3. Run `sail up -d` or `./vendor/bin/sail up`.
4. Run `sail npm install` or `./vendor/bin/sail npm install`.
5. Run `sail npm run build` or `./vendor/bin/sail npm run build`.
6. Run `sail artisan migrate` or `./vendor/bin/sail artisan migrate`.
7. Open `localhost:8080` in your browser or the preferred port stated in .env file.

### Common issues

Can't connect to database. If you see this error and you are using sail,make sure your mysql host is called mysql instead of localhost.  

### References

* Tabler.io https://tabler.io/
* Laravel Sail https://laravel.com/docs/10.x/sail
* Laravel Breeze https://laravel.com/docs/10.x/starter-kits#laravel-breeze
