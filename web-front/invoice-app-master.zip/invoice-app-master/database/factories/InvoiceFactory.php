<?php

namespace Database\Factories;

use App\Models\Client;
use App\Models\Company;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Company>
 */
class InvoiceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => 'Invoice for '.fake()->company(),
            'user_id' => User::factory(),
            'company_id' => Company::factory(),
            'client_id' => Client::factory(),
            'due_date' => fake()->dateTimeThisYear,
            'issue_date' => fake()->dateTimeThisYear,
            'tax' => fake()->numberBetween(0, 100),
            'currency' => fake()->randomElement([
                'GBP',
                'BRL',
                'USD',
            ]),
        ];

    }
}
