<?php

namespace Database\Seeders;

use App\Models\InvoiceItem;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        //        \App\Models\User::factory(20)->create();

        //        $user = \App\Models\User::factory()->create([
        //            'name' => 'henrique',
        //            'email' => 'henriquediasjr@gmail.com',
        //            'password' => 'henrique',
        //            'status' => 1,
        //        ]);
        //
        //        event(new Registered($user));

        $this->call([
            CompanySeeder::class,
            ClientSeeder::class,
            InvoiceSeeder::class,
            InvoiceItem::class,
        ]);

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
