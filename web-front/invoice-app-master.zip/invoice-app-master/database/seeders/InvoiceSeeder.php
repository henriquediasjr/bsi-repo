<?php

namespace Database\Seeders;

use App\Models\Client;
use App\Models\Company;
use App\Models\Invoice;
use Illuminate\Database\Seeder;

class InvoiceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Invoice::factory()
            ->count(10)
            ->hasInvoiceItems(5, [
                'title' => 'Invoice item',
                'description' => fake()->text(),
                'quantity' => fake()->randomDigit(),
                'unit' => fake()->randomDigit(),
                'amount' => fake()->randomDigit(),
            ])
            ->create([
                'client_id' => Client::factory(),
                'company_id' => Company::factory(),
                'user_id' => 1,
            ]);
    }
}
