<?php

namespace Database\Seeders;

use App\Models\Client;
use Illuminate\Database\Seeder;

class ClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //         \App\Models\Client::factory(20)->create();

        //        Client::factory()
        //            ->count(25)
        //            ->hasInvoices(3, [
        //                'title' => fake()->name(),
        //                'user_id' => 1,
        //            ])->hasInvoiceItems(5)
        //            ->create();
    }
}
