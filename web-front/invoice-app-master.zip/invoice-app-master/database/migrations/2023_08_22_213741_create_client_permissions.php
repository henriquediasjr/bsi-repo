<?php

use Illuminate\Database\Migrations\Migration;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $permission1 = Permission::create(['name' => __('add client')]);
        $permission2 = Permission::create(['name' => __('delete client')]);
        $permission3 = Permission::create(['name' => __('edit client')]);
        $permission4 = Permission::create(['name' => __('view clients')]);

        $roleAdmin = Role::find(1);
        $roleAdmin->givePermissionTo($permission1);
        $roleAdmin->givePermissionTo($permission2);
        $roleAdmin->givePermissionTo($permission3);
        $roleAdmin->givePermissionTo($permission4);

        $roleUser = Role::find(2);
        $roleUser->givePermissionTo($permission1);
        $roleUser->givePermissionTo($permission3);
        $roleUser->givePermissionTo($permission4);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // none
    }
};
