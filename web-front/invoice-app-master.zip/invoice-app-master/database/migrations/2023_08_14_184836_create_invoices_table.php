<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->string('title');
            $table->integer('user_id');
            $table->integer('company_id');
            $table->integer('client_id');
            $table->date('due_date');
            $table->date('issue_date');
            $table->float('tax')->nullable();
            $table->string('currency');
        });

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->integer('invoice_id');
            $table->integer('order');
            $table->string('title')->nullable();
            $table->string('description')->nullable();
            $table->float('quantity');
            $table->float('unit');
            $table->float('amount');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('invoices');
        Schema::dropIfExists('invoice_items');
    }
};
