<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Routing\Controller as BaseController;

class DashboardController extends BaseController
{
    public function index()
    {
        $builder = (new Invoice())
            ->with('invoiceItems');

        $invoices = Invoice::getLatestInvoices($builder);
        //        $builder = (new Invoice());

        //        $builder->whereHas('timestamp', function(Builder $query){
        //            $query
        //    });

        //        echo "<pre>" . $invoices . "</pre>"; exit();

        return view('dashboard', [
            'invoices' => $invoices,
        ]);
    }
}
