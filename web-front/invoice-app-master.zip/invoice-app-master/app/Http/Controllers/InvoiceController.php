<?php

namespace App\Http\Controllers;

use App\Exports\ExportCompanies;
use App\Models\Client;
use App\Models\Company;
use App\Models\Invoice;
use App\Models\InvoiceItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;

class InvoiceController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $limit = intval($request->get('limit', 25));
        $order = $request->get('orderby', 'invoices.id');
        $orderDirection = $request->get('orderDir', 'asc');

        /** @var \Illuminate\Database\Eloquent\Builder $builder */
        $builder = (new Invoice())
            ->with('client')
            ->with('company');

        if (! empty($search)) {
            $builder->whereHas('client', function ($q) use ($search) {
                $q->where('clients.name', 'like', '%'.$search.'%');
            });
        }

        $builder->orderBy($order, $orderDirection);
        $invoices = $builder->paginate($limit);
        $urlParams = [
            'limit' => $limit,
            'status' => $status,
            'uf' => $uf,
            'city' => $city,
            'cnae' => $cnae,
            'service' => $service,
            'search' => $search,
            'order' => $order,
            'orderDir' => $orderDirection,
        ];

        //$invoices->appends($urlParams);

        return view('invoice.list', [
            'invoices' => $invoices,
            'isMoreOpen' => $this->isMoreOpen($urlParams),
            'filters' => $urlParams,
        ]);
    }

    public function export(Request $request)
    {
        ini_set('memory_limit', '1G');
        ini_set('max_execution_time', '60');

        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');

        /* \Illuminate\Database\Query\Builder */
        $invoicesBuilder = Invoice::search(
            DB::table('invoices')->select('invoices.*'),
            $search,
            $status,
            $service,
            $uf,
            $city,
            $cnae,
        )->orderBy('invoices.'.$order, $orderDirection);

        return Excel::download((new ExportCompanies($invoicesBuilder)), 'empresas-'.date('Y-m-d-H-i').'.xlsx', null, [
            'Cache-Control' => 'private, max-age=3600',
        ]);

    }

    public function create(): View
    {
        return view('invoice.create', [
            'invoice' => new Invoice(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        if (! $validated) {
            return redirect('invoices')
                ->with('error', 'Cannot create invoice');
        } else {

            $invoice = Invoice::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'country' => $request->country,
                'address' => $request->address,
                'address_number' => $request->address_number,
                'address_complement' => $request->address_complement,
                'address_cep' => $request->address_cep,

            ]);

            $input = $request->all();

            $invoice->update($input);

            return redirect('invoices')->with('success', 'Successfully created a invoice!');
        }
    }

    public function show(Invoice $invoice)
    {

        return view('invoice.show', [
            'badgesClasses' => [
                1 => 'bg-blue-lt',
                2 => 'bg-purple-lt',
                3 => 'bg-pink-lt',
                4 => 'bg-yellow-lt',
                5 => 'bg-green-lt',
                6 => 'bg-orange-lt',
                7 => 'bg-teal-lt',
            ],
        ])->with('invoice', $invoice);
    }

    public function edit(Invoice $invoice)
    {
        $user = auth()->user();
        $invoice->load('client', 'company', 'invoiceItems');
        $clients = $user->clients->load('invoices');
        $companies = Company::all()->load('invoices');

        return view('invoice.edit', [
            'invoice' => $invoice,
            'clients' => $clients,
            'companies' => $companies,
        ]);
    }

    public function update(Request $request, Invoice $invoice)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        // process the login
        if (! $validated) {
            return redirect('invoices')
                ->with('error', 'Cannot create invoice');
        } else {

            $input = $request->all();

            $invoice->update($input);

            return redirect(route('invoices.show', ['invoice' => $invoice->id]))->with('success', 'Successfully updated invoice!');
        }
    }

    public function destroy(Invoice $invoice)
    {
        $invoice->delete();

        return redirect(route('invoices.index'))
            ->with('success', 'Invoice successful deleted.');
    }

    private function isMoreOpen($filters)
    {
        return ($filters['status'] !== 'Todos' && ($filters['status'] !== '')) ||
        ($filters['service'] !== 'Todos' && ($filters['service'] > 0)) ||
        (! empty($filters['cnae'])) ||
        (! empty($filters['city'])) ||
        (! empty($filters['partner'])) ||
        ($filters['uf'] !== 'Todos' && ! empty($filters['uf']));
    }

    public function clientChange(Request $request)
    {
        try {
            $request->validate([
                'clientId' => ['required', 'integer'],
                'invoiceId' => ['required', 'integer'],
            ]);

        } catch (\Exception $e) {
            echo $e->getMessage();
            exit;
        }

        $client = Client::find($request->clientId);
        $invoice = Invoice::find($request->invoiceId);
        $invoice->client_id = $client->id;
        $invoice->save();

        return $client;
    }

    public function companyChange(Request $request)
    {
        try {
            $request->validate([
                'companyId' => ['required', 'integer'],
                'invoiceId' => ['required', 'integer'],
            ]);

        } catch (\Exception $e) {
            echo $e->getMessage();
            exit;
        }
        $company = Company::find($request->companyId);
        $invoice = Invoice::find($request->invoiceId);
        $invoice->company_id = $company->id;
        $invoice->save();

        return $company;
    }

    public function invoiceSave(Request $request)
    {
        try {
            $request->validate([
                'invoiceData' => ['required'],
                'vatRate' => ['required'],
                'issueDate' => ['required'],
                'dueDate' => ['required'],
                'invoiceItems' => ['required'],
            ]);

            $invoiceId = $request->input('invoiceData.id');
            $invoice = Invoice::with('invoiceItems')->find($invoiceId);
            $invoiceItems = InvoiceItem::all()->where('invoice_id', $invoiceId);

            $this->addAndUpdateInvoiceItems($request, $invoiceItems);

            $this->updateInvoiceFields($request, $invoice);

            $this->deleteInvoiceItems($request, $invoiceItems);

        } catch (\Exception $e) {
            echo $e->getMessage();
            exit;
        }

       return $invoice;
    }

    private function updateInvoiceFields($request, $dbInvoice)
    {
        $dbInvoice->title = $request->input('invoiceData.title');
        $dbInvoice->currency = $request->input('invoiceData.currency');
        $dbInvoice->company_id = $request->input('invoiceData.company_id');
        $dbInvoice->client_id = $request->input('invoiceData.client_id');
        $dbInvoice->tax = $request->input('vatRate');
        $dbInvoice->due_date = $request->input('dueDate');
        $dbInvoice->issue_date = $request->input('issueDate');
        $dbInvoice->save();
    }

    private function addAndUpdateInvoiceItems($request, $dbInvoiceItems)
    {
        $invoiceId = $request->input('invoiceData.id');
        $newResponses = $request->input('invoiceItems');

        foreach ($newResponses as $value) {
            if ($value['id'] == null) {
                InvoiceItem::create([
                    'amount' => $value['amount'],
                    'description' => $value['description'],
                    'invoice_id' => $invoiceId,
                    'order' => $value['order'],
                    'quantity' => $value['quantity'],
                    'title' => $value['title'],
                    'unit' => $value['unit'],
                ])->save();
            }

            foreach ($dbInvoiceItems as $item) {
                if ($value['id'] == $item->id) {
                    $item->amount = $value['amount'];
                    $item->description = $value['description'];
                    $item->order = $value['order'];
                    $item->quantity = $value['quantity'];
                    $item->title = $value['title'];
                    $item->unit = $value['unit'];
                    $item->save();
                }
            }
        }
    }

    private function deleteInvoiceItems($request, $dbInvoiceItems)
    {
        $invoiceId = $request->input('invoiceData.id');
        $newResponses = $request->input('invoiceItems');
        $responseItemsIds = array_column($newResponses, 'id');
        $dbInvoiceItemsIds = array_column($dbInvoiceItems->toArray(), 'id');
        $forDeletionItems = array_diff($dbInvoiceItemsIds, $responseItemsIds);
        $getInvoicesToDelete = $dbInvoiceItems->find($forDeletionItems);
        foreach ($getInvoicesToDelete as $item) {
            $item->delete();
        }
    }
}
