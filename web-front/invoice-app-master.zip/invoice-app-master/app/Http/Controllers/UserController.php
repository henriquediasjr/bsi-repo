<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Illuminate\View\View;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');
        $status = intval($request->get('status', 0));
        $limit = intval($request->get('limit', 25));
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');

        /* \Illuminate\Database\Query\Builder */
        $users = User::search(
            DB::table('users'),
            $search,
            $status
        )->orderBy($order, $orderDirection)->paginate($limit);

        $urlParams = [
            'limit' => $limit,
            'status' => $status,
            'search' => $search,
            'order' => $order,
            'orderDir' => $orderDirection,
        ];

        $users->appends($urlParams);

        return view('user.list', [
            'users' => $users,
            'options' => User::statuses(),
            'filters' => $urlParams,
        ]);
    }

    public function create(): View
    {
        return view('user.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:'.User::class],
            'password' => ['required', Rules\Password::defaults()],
        ]);

        // process the login
        if (! $validated) {
            return redirect('users')
                ->with('error', 'Cannot create user');
        } else {

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
            ]);

            event(new Registered($user));

            return redirect('users')->with('success', 'Successfully created a user!');
        }
    }

    public function show(User $user)
    {
        return view('user.show')->with('user', $user);
    }

    public function edit(User $user)
    {
        return view('user.edit', [
            'user' => $user,
        ]);
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
        ]);

        // process the login
        if (! $validated) {
            return redirect('users')
                ->with('error', 'Cannot create user');
        } else {

            $input = $request->all();

            if ($input['password']) {
                $input['password'] = Hash::make($request->password);
            } else {
                unset($input['password']);
            }

            $input['status'] = (isset($input['status'])) ? true : false;

            $user->update($input);

            return redirect('users')->with('success', 'Successfully updated user!');
        }
    }

    public function destroy(User $user)
    {
        $user->delete();

        return redirect(route('users.index'))
            ->with('success', 'User successfully deleted.');
    }
}
