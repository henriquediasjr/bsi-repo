<?php

namespace App\Http\Controllers;

use App\Exports\ExportCompanies;
use App\Models\Client;
use App\Models\Comment;
use App\Models\Contact;
use App\Models\Document;
use App\Models\Reminder;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\File;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;

class ClientsController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $partner = $request->get('partner', null);
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $limit = intval($request->get('limit', 25));
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');
        /* \Illuminate\Database\Query\Builder */
        $clientsBuilder = Client::search(
            DB::table('clients')
                ->select('clients.*')
                ->where('user_id', auth()->user()->id),
            $search
        )->orderBy('clients.'.$order, $orderDirection);
        $clients = $clientsBuilder->paginate($limit);

        $urlParams = [
            'limit' => $limit,
            'status' => $status,
            'partner' => $partner,
            'uf' => $uf,
            'city' => $city,
            'cnae' => $cnae,
            'service' => $service,
            'search' => $search,
            'order' => $order,
            'orderDir' => $orderDirection,
        ];

        $clients->appends($urlParams);

        return view('clients.list', [
            'clients' => $clients,
            'isMoreOpen' => $this->isMoreOpen($urlParams),
            'filters' => $urlParams,
        ]);
    }

    public function export(Request $request)
    {
        ini_set('memory_limit', '1G');
        ini_set('max_execution_time', '60');

        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $partner = $request->get('partner', null);
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');

        /* \Illuminate\Database\Query\Builder */
        $clientsBuilder = Client::search(
            DB::table('clients')->select('clients.*'),
            $search,
            $status,
            $service,
            $uf,
            $city,
            $cnae,
            $partner
        )->orderBy('clients.'.$order, $orderDirection);

        return Excel::download((new ExportCompanies($clientsBuilder)), 'empresas-'.date('Y-m-d-H-i').'.xlsx', null, [
            'Cache-Control' => 'private, max-age=3600',
        ]);

    }

    private function isMoreOpen($filters)
    {
        return ($filters['status'] !== 'Todos' && ($filters['status'] !== '')) ||
        ($filters['service'] !== 'Todos' && ($filters['service'] > 0)) ||
        (! empty($filters['cnae'])) ||
        (! empty($filters['city'])) ||
        (! empty($filters['partner'])) ||
        ($filters['uf'] !== 'Todos' && ! empty($filters['uf']));
    }

    public function create(): View
    {
        return view('clients.create', [
            'client' => new Client(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        if (! $validated) {
            return redirect('clients')
                ->with('error', 'Cannot create client');
        } else {

            $client = Client::create([
                'name' => $request->name,
            ]);

            $input = $request->all();

            $client->update($input);

            return redirect('clients')->with('success', 'Successfully created a client!');
        }
    }

    public function show(Client $client)
    {

        return view('clients.show', [
            'badgesClasses' => [
                1 => 'bg-blue-lt',
                2 => 'bg-purple-lt',
                3 => 'bg-pink-lt',
                4 => 'bg-yellow-lt',
                5 => 'bg-green-lt',
                6 => 'bg-orange-lt',
                7 => 'bg-teal-lt',
            ],
        ])->with('client', $client);
    }

    public function edit(Client $client)
    {
        return view('clients.edit', [
            'client' => $client,
        ]);
    }

    public function update(Request $request, Client $client)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        // process the login
        if (! $validated) {
            return redirect('clients')
                ->with('error', 'Cannot create client');
        } else {

            $input = $request->all();

            $client->update($input);

            return redirect(route('clients.show', ['client' => $client->id]))->with('success', 'Successfully updated client!');
        }
    }

    public function destroy(Client $client)
    {
        $client->delete();

        return redirect(route('clients.index'))
            ->with('success', 'Client successful deleted.');
    }

    public function download(Client $client, $document)
    {
        $doc = Document::find($document);
        $path = $doc->filepath;
        $response = Storage::disk('google')->download($path, $doc->filename);
        $response->send();
    }

    public function upload(Request $request)
    {
        try {
            $validated = $request->validate([
                'file' => ['required', File::types(['png', 'pdf', 'jpg', 'jpeg'])],
                'client_id' => ['required', 'string'],
                'comment' => ['required', 'string'],
            ]);
        } catch (\Exception $e) {
            echo $e->getMessage();
            exit;
        }

        Storage::disk('google')->makeDirectory($request->get('client_id'));

        $file = $request->file('file');
        $fileName = $file->getClientOriginalName();

        $path = Storage::disk('google')
            ->putFileAs($request->get('client_id'), $request->file('file'), $fileName);

        Document::create([
            'comment' => $request->comment,
            'user_id' => Auth::user()->id,
            'client_id' => $request->client_id,
            'size' => $file->getSize(),
            'filename' => $fileName,
            'filepath' => $path,
        ]);

        if (! $validated) {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('error', 'Cannot add the file');
        } else {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('success', 'File added!');
        }

    }

    public function contact(Request $request)
    {
        $validated = $request->validate([
            'type' => ['required'],
            'client_id' => ['required', 'string'],
            'data' => ['required', 'string'],
        ]);

        Contact::create([
            'observation' => $request->observation,
            'user_id' => Auth::user()->id,
            'client_id' => $request->client_id,
            'type' => $request->type,
            'data' => $request->data,
        ]);

        if (! $validated) {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('error', 'Cannot add contact');
        } else {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('success', 'Contact added!');
        }

    }

    public function contactDelete(Client $client, $contact)
    {
        Contact::find($contact)->delete();

        return redirect(route('clients.show', ['client' => $client->id]))
            ->with('success', 'Contact deleted!');

    }

    public function commentDelete(Client $client, int $comment)
    {
        if ($commentObj = Comment::find($comment)) {
            $commentObj->delete();
        } else {
            return abort(403, trans('clients::crud.objectnotfound'));
        }

        return redirect(route('clients.show', ['client' => $client->id]))
            ->with('success', 'Comment deleted!');
    }

    public function reminderDelete(Client $client, int $reminder)
    {
        if ($commentObj = Reminder::find($reminder)) {
            Reminder::where('parent', '=', $reminder)->delete();
            $commentObj->delete();
        } else {
            return abort(403, trans('clients::crud.objectnotfound'));
        }

        return redirect(route('clients.show', ['client' => $client->id]))
            ->with('success', 'Reminder deleted!');
    }

    public function reminderFlag(Client $client, int $reminder)
    {
        if ($commentObj = Reminder::find($reminder)) {
            $commentObj->update(['read' => true]);
        } else {
            return abort(403, trans('clients::crud.objectnotfound'));
        }

        return redirect(route('clients.show', ['client' => $client->id]))
            ->with('success', 'Reminder marked as read!');
    }

    public function documentDelete(Client $client, int $upload)
    {
        if ($uploadObj = Document::find($upload)) {
            $uploadObj->delete();
        } else {
            return abort(403, trans('clients::crud.objectnotfound'));
        }

        return redirect(route('clients.show', ['client' => $client->id]))
            ->with('success', 'Upload deleted!');
    }

    public function comment(Request $request)
    {
        $validated = $request->validate([
            'comment' => ['required', 'string'],
            'client_id' => ['required', 'integer'],
        ]);

        Comment::create([
            'comment' => $request->comment,
            'user_id' => Auth::user()->id,
            'client_id' => $request->client_id,
        ]);

        if (! $validated) {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('error', 'Cannot add a comment');
        } else {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('success', 'Comment created!');
        }
    }

    private function subReminder($reminder, $date)
    {
        return Reminder::create([
            'description' => $reminder->description,
            'client_id' => $reminder->client_id,
            'start_date' => $date,
            'parent' => $reminder->id,
            'user_id' => $reminder->user_id,
            'frequency' => Reminder::doNotRepeat,
        ]);
    }

    public function reminder(Request $request)
    {
        $validated = $request->validate([
            'description' => ['required', 'string'],
            'start_date' => ['required', 'date_format:d/m/Y'],
            'frequency' => ['required'],
            'client_id' => ['required', 'integer'],
        ]);

        $reminder = Reminder::create([
            'description' => $request->description,
            'client_id' => $request->client_id,
            'start_date' => Carbon::createFromFormat('d/m/Y', $request->start_date),
            'user_id' => Auth::user()->id,
            'frequency' => $request->frequency,
        ]);

        $this->generateFutureReminders($reminder);

        if (! $validated) {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('error', 'Cannot add the reminder');
        } else {
            return redirect(route('clients.show', ['client' => $request->client_id]))
                ->with('success', 'Reminder created!');
        }
    }

    private function generateFutureReminders($reminder)
    {
        if (in_array($reminder->frequency, ['yearly', 'monthly', 'every 2 years', 'every 3 years', 'every 4 years', 'every 5 years'])) {

            $yearsAhead = 2;
            $start = $reminder->start_date;

            if ($reminder->frequency === 'yearly') {
                for ($i = 0; $i < $yearsAhead; $i++) {
                    $this->subReminder($reminder, $start->addYear());
                }
            }

            if ($reminder->frequency === 'monthly') {
                for ($i = 0; $i < $yearsAhead; $i++) {
                    for ($x = 1; $x <= 12; $x++) {
                        $start->addMonth();
                        $this->subReminder($reminder, clone $start);
                    }
                    $start->addYear();
                    $start->setMonth(1);
                }
            }

            if ($reminder->frequency === 'every 2 years') {
                for ($i = 0; $i < ($yearsAhead * 5); $i += 2) {
                    $start->addYears(2);
                    $this->subReminder($reminder, clone $start);
                }
            }

            if ($reminder->frequency === 'every 3 years') {
                for ($i = 0; $i < ($yearsAhead * 5); $i += 3) {
                    $start->addYears(3);
                    $this->subReminder($reminder, clone $start);
                }
            }

            if ($reminder->frequency === 'every 4 years') {
                for ($i = 0; $i < ($yearsAhead * 5); $i += 4) {
                    $start->addYears(4);
                    $this->subReminder($reminder, clone $start);
                }
            }

            if ($reminder->frequency === 'every 5 years') {
                for ($i = 0; $i < ($yearsAhead * 5); $i += 5) {
                    $start->addYears(5);
                    $this->subReminder($reminder, clone $start);
                }
            }

        }
    }
}
