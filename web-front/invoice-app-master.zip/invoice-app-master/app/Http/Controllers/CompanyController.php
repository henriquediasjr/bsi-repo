<?php

namespace App\Http\Controllers;

use App\Exports\ExportCompanies;
use App\Models\Company;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;
use Maatwebsite\Excel\Facades\Excel;

class CompanyController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $limit = intval($request->get('limit', 25));
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');

        /* \Illuminate\Database\Query\Builder */
        $companiesBuilder = Company::search(
            DB::table('companies')->select('companies.*'),
            $search
        )->orderBy('companies.'.$order, $orderDirection);
        $companies = $companiesBuilder->paginate($limit);

        $urlParams = [
            'limit' => $limit,
            'status' => $status,
            'uf' => $uf,
            'city' => $city,
            'cnae' => $cnae,
            'service' => $service,
            'search' => $search,
            'order' => $order,
            'orderDir' => $orderDirection,
        ];

        $companies->appends($urlParams);

        return view('company.list', [
            'companies' => $companies,
            'isMoreOpen' => $this->isMoreOpen($urlParams),
            'filters' => $urlParams,
        ]);
    }

    public function export(Request $request)
    {
        ini_set('memory_limit', '1G');
        ini_set('max_execution_time', '60');

        $search = $request->get('search');
        $status = $request->get('status', 'Todos');
        $uf = $request->get('uf', 'Todos');
        $service = $request->get('service', '');
        $cnae = $request->get('cnae', null);
        $city = $request->get('city', null);
        $order = $request->get('orderby', 'name');
        $orderDirection = $request->get('orderDir', 'asc');

        /* \Illuminate\Database\Query\Builder */
        $companiesBuilder = Company::search(
            DB::table('companies')->select('companies.*'),
            $search,
            $status,
            $service,
            $uf,
            $city,
            $cnae,
        )->orderBy('companies.'.$order, $orderDirection);

        return Excel::download((new ExportCompanies($companiesBuilder)), 'empresas-'.date('Y-m-d-H-i').'.xlsx', null, [
            'Cache-Control' => 'private, max-age=3600',
        ]);

    }

    public function create(): View
    {
        return view('company.create', [
            'company' => new Company(),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        if (! $validated) {
            return redirect('companies')
                ->with('error', 'Cannot create company');
        } else {

            $company = Company::create([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'country' => $request->country,
                'address' => $request->address,
                'address_number' => $request->address_number,
                'address_complement' => $request->address_complement,
                'address_cep' => $request->address_cep,

            ]);

            $input = $request->all();

            $company->update($input);

            return redirect('companies')->with('success', 'Successfully created a company!');
        }
    }

    public function show(Company $company)
    {

        return view('company.show', [
            'badgesClasses' => [
                1 => 'bg-blue-lt',
                2 => 'bg-purple-lt',
                3 => 'bg-pink-lt',
                4 => 'bg-yellow-lt',
                5 => 'bg-green-lt',
                6 => 'bg-orange-lt',
                7 => 'bg-teal-lt',
            ],
        ])->with('company', $company);
    }

    public function edit(Company $company)
    {

        return view('company.edit', [
            'company' => $company,
        ]);
    }

    public function update(Request $request, Company $company)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
        ]);

        // process the login
        if (! $validated) {
            return redirect('companies')
                ->with('error', 'Cannot create company');
        } else {

            $input = $request->all();
            $company->update($input);

            return redirect(route('companies.show', ['company' => $company->id]))->with('success', 'Successfully updated company!');
        }
    }

    public function destroy(Company $company)
    {
        $company->delete();

        return redirect(route('companies.index'))
            ->with('success', 'Company successful deleted.');
    }

    private function isMoreOpen($filters)
    {
        return ($filters['status'] !== 'Todos' && ($filters['status'] !== '')) ||
        ($filters['service'] !== 'Todos' && ($filters['service'] > 0)) ||
        (! empty($filters['cnae'])) ||
        (! empty($filters['city'])) ||
        (! empty($filters['partner'])) ||
        ($filters['uf'] !== 'Todos' && ! empty($filters['uf']));
    }
}
