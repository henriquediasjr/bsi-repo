<?php

namespace App\Listeners;

use Illuminate\Auth\Events\Registered;
use Spatie\Permission\Models\Role;

class AutoUserRoleAssignmentListener
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(Registered $event): void
    {
        /* \App\Models\User $user */
        $user = $event->user;

        if ($user->id === 1) {
            $this->assignAdminRole($user);
        } else {
            $this->assignUserRole($user);
        }
    }

    private function assignAdminRole(\App\Models\User $user): void
    {
        if ($roleAdmin = Role::find(1)) {
            $user->assignRole($roleAdmin);
        }
    }

    private function assignUserRole(\App\Models\User $user): void
    {
        if ($role = Role::find(2)) {
            $user->assignRole($role);
        }
    }
}
