<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\Builder;

class Client extends Model
{
    use HasFactory;

    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'id',
        'name',
        'email',
        'phone',
        'country',
        'city',
        'address',
        'address_number',
        'address_complement',
        'address_cep',
        'currency',
        'user_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = ['updated_at', 'created_at'];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
    ];

    public static function search(Builder $clients, $search)
    {
        $clients = self::searchByName($clients, $search);

        return $clients;
    }

    public static function searchByName(Builder &$clients, $search)
    {
        if ($search) {
            $clients->where(function ($query) use ($search) {

                if (is_numeric($search)) {
                    $query->where('clients.name', '=', $search);
                } else {
                    $query->where('clients.name', 'like', '%'.$search.'%');
                }
            });
        }

        return $clients;
    }

    /**
     * Get the invoice that the client owns.
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * Get the user that the client belongs to.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
