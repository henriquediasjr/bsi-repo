<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\Builder;

class Company extends Model
{
    use HasFactory;

    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'country',
        'city',
        'address',
        'address_number',
        'address_complement',
        'address_cep',
        'user_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = ['updated_at', 'created_at'];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
    ];

    public static function search(Builder $companies, $search)
    {
        $companies = self::searchByName($companies, $search);

        return $companies;
    }

    public static function searchByName(Builder &$companies, $search)
    {
        if ($search) {
            $companies->where(function ($query) use ($search) {

                if (is_numeric($search)) {
                    $query->where('companies.name', '=', $search);
                } else {
                    $query->where('companies.name', 'like', '%'.$search.'%');
                }
            });
        }

        return $companies;
    }

    /**
     * Get the user that made the invoice.
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * Get the user this company belong to
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
