<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Query\Builder;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [
        'status' => false,
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'status',
        'phone',
        'country',
        'address',
        'address_number',
        'address_complement',
        'address_cep',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'status' => 'boolean',
    ];

    public function isActive()
    {
        return $this->status === true;
    }

    public function isInactive()
    {
        return $this->status === false;
    }

    public static function search(Builder $users, $search, $status)
    {
        $users = self::searchByNameAndEmail($users, $search);
        $users = self::searchByStatus($users, $status);

        return $users;
    }

    private static function searchByStatus(Builder &$users, $status)
    {
        if ($status > 0) {
            return $users->where('status', '=', ($status == 2) ? 0 : 1);
        }

        return $users;
    }

    public static function searchByNameAndEmail(Builder &$users, $search)
    {
        if ($search) {
            $users->where(function ($query) use ($search) {
                $query->where('name', 'like', '%'.$search.'%')
                    ->orWhere('email', 'like', '%'.$search.'%');
            });
        }

        return $users;
    }

    public static function statuses()
    {
        return [[
            'id' => '0',
            'title' => 'All',
        ], [
            'id' => '1',
            'title' => 'Active',
        ], [
            'id' => '2',
            'title' => 'Inactive',
        ]];
    }

    /**
     * Get the invoice made by the user.
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * Get the Clients made by the user.
     */
    public function clients(): HasMany
    {
        return $this->hasMany(Client::class);
    }

    /**
     * Get the company from the client
     */
    public function company(): HasOne
    {
        return $this->hasOne(Company::class);
    }
}
