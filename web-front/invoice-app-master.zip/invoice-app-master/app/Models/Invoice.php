<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\Builder;

class Invoice extends Model
{
    use HasFactory;

    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'title',
        'user_id',
        'company_id',
        'client_id',
        'due_date',
        'issue_date',
        'tax',
        'currency',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
    ];

    /**
     * Get the items for the Invoice.
     */
    public function invoiceItems(): HasMany
    {
        return $this->hasMany(InvoiceItem::class);
    }

    /**
     * Get the company that owns the invoice.
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * Get the client that owns the invoice.
     */
    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    /**
     * Get the user that made the invoice.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public static function search(Builder $invoices, $search)
    {
        $invoices = self::searchByName($invoices, $search);

        return $invoices;
    }

    public static function searchByName(Builder &$invoices, $search)
    {
        if ($search) {
            $invoices->where(function ($query) use ($search) {

                if (is_numeric($search)) {
                    $query->where('invoices.title', '=', $search);
                } else {
                    $query->where('invoices.title', 'like', '%'.$search.'%');
                }
            });
        }

        return $invoices;
    }

    public function getSubtotalAttribute()
    {
        $subtotal = 0;

        foreach ($this->invoiceItems as $item) {
            $subtotal += $item->amount;
        }

        return $subtotal;
    }

    public static function getLatestInvoices($invoices)
    {
        return $invoices
            ->orderBy('updated_at', 'desc')
            ->limit(4)
            ->get();

    }
}
