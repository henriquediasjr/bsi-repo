<x-guest-layout>
    <div class="card card-md">
        <div class="card-body">
                <h2 class="h2 text-center mb-4">{{__('Login to your account')}}</h2>

                <!-- Session Status -->
                <x-auth-session-status class="mb-4" :status="session('status')" />

                <form method="POST" action="{{ route('login') }}" autocomplete="off" novalidate>
                    @csrf
                    <div class="mb-3">
                            <x-input-label for="email" :value="__('Email address')" />
                            <x-text-input id="email" class="form-control {{$errors->has('email') ? 'is-invalid' : '' }}" type="email" name="email" placeholder="{{__('your@email.com')}}" :value="old('email')" autofocus autocomplete="off" />
                            <x-input-error :messages="$errors->get('email')" class="invalid-feedback mt-2" />
                    </div>

                    <div class="mb-2">
                        <label class="form-label">
                            {{__('Password')}}
                            <span class="form-label-description">
                                @if (Route::has('password.request'))
                                    <a href="{{ route('password.request') }}">{{ __('Forgot your password?') }}</a>
                                @endif
                            </span>
                        </label>

                        <div class="mb-3">
                            <x-text-input id="password" class="form-control {{$errors->has('email') ? 'is-invalid' : '' }}"
                                          type="password"
                                          name="password"
                                          placeholder="{{__('Your password')}}"
                                          autocomplete="current-password" />
                            <x-input-error :messages="$errors->get('password')" class="invalid-feedback mt-2" />
                        </div>
                    </div>

                    <div class="mb-2">
                        <label class="form-check">
                            <input type="checkbox" class="form-check-input" id="remember_me" />
                            <span class="form-check-label">{{__('Remember me on this device') }}</span>
                        </label>
                    </div>
                    <div class="form-footer">
                        <x-primary-button class="btn btn-primary w-100">
                            {{ __('Sign in') }}
                        </x-primary-button>
                    </div>
                </form>
        </div>

    </div>
    <div class="text-center text-muted mt-3">
        @if ($allowSignUp)
            {{ __("Don't have an account yet?") }} <a href="{{ route('register') }}" tabindex="-1">{{ __('Sign up') }}</a>
        @endif
    </div>
</x-guest-layout>
