@props(['messages'])

@if ($messages)
    <div {{ $attributes->merge(['class' => '']) }}>
        @foreach ((array) $messages as $message)
            {{ $message }}
        @endforeach
    </div>
@endif
