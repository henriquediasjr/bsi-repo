<button {{ $attributes->merge(['type' => 'button', 'class' => '']) }}>
    {{ $slot }}
</button>
