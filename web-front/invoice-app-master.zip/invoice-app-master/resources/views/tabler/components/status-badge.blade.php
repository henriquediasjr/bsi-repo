@props(['status'])

<span {{ $attributes->merge(['class' => 'status ' . ($status == 1 ? 'status-green' : 'status-teal')]) }}>
    {{ $status == 1 ? 'Active' : 'Inactive' }}
</span>
