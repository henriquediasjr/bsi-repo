@props(['active'])

@php
$classes = ($active ?? false)
            ? 'nav-link'
            : 'nav-link';
@endphp

<span class="nav-link-title">
     <a {{ $attributes->merge(['class' => $classes]) }} href="{{ route('profile.edit') }}">
         {{ $slot }}
     </a>
</span>
