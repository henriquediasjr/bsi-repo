<a href="." class="navbar-brand navbar-brand-autodark"   {{ $attributes }}>
    <img src="{{ Vite::asset('resources/images/logo.svg') }}" height="36" width="123" alt="Logo" class="navbar-brand-image">
</a>
