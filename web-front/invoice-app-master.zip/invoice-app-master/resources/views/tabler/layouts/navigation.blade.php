<aside class="navbar navbar-vertical navbar-expand-lg" data-bs-theme="dark">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu" aria-controls="sidebar-menu" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <h1 class="navbar-brand navbar-brand-autodark">
            <x-application-logo />
        </h1>

        <div class="navbar-collapse collapse" id="sidebar-menu">
            <ul class="navbar-nav pt-lg-3">
                <li class="nav-item">
                    <x-nav-link :href="route('home')" :active="request()->routeIs('home')" class="nav-link-title">
                        <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/home -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l-2 0l9 -9l9 9l-2 0" /><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7" /><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6" /></svg>
                        </span>
                        {{ __('Dashboard') }}
                    </x-nav-link>

                </li>

                @can('view users')
                    <li>
                        <x-nav-link :href="route('users.index')" :active="request()->routeIs('users.index')" class="nav-link-title">
                        <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/user -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users-group" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                           <path d="M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1"></path>
                           <path d="M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M17 10h2a2 2 0 0 1 2 2v1"></path>
                           <path d="M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M3 13v-1a2 2 0 0 1 2 -2h2"></path>
                        </svg>
                        </span>
                            {{ __('Users') }}
                        </x-nav-link>
                    </li>
                @endcan

                @can('view invoices')
                    <li>
                        <x-nav-link :href="route('invoices.index')" :active="request()->routeIs('invoices.index')" class="nav-link-title">
                        <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/user -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users-group" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                           <path d="M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1"></path>
                           <path d="M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M17 10h2a2 2 0 0 1 2 2v1"></path>
                           <path d="M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M3 13v-1a2 2 0 0 1 2 -2h2"></path>
                        </svg>
                        </span>
                            {{ __('Invoices') }}
                        </x-nav-link>
                    </li>
                @endcan

                @can('view clients')
                <li>
                    <x-nav-link :href="route('clients.index')" :active="request()->routeIs('clients.index')" class="nav-link-title">
                        <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/user -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-users-group" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                           <path d="M10 13a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M8 21v-1a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v1"></path>
                           <path d="M15 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M17 10h2a2 2 0 0 1 2 2v1"></path>
                           <path d="M5 5a2 2 0 1 0 4 0a2 2 0 0 0 -4 0"></path>
                           <path d="M3 13v-1a2 2 0 0 1 2 -2h2"></path>
                        </svg>
                        </span>
                        {{ __('Clients') }}
                    </x-nav-link>
                </li>
                @endcan

                <li>
                    <x-nav-link :href="route('profile.edit')" :active="request()->routeIs('profile.edit')" class="nav-link-title">
                        <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/user -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-user" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                           <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"></path>
                           <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path>
                        </svg>
                        </span>
                        {{ __('Profile') }}
                    </x-nav-link>
                </li>

                <li>
                    <!-- Authentication -->
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <x-nav-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                        this.closest('form').submit();">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><!-- Download SVG icon from http://tabler-icons.io/i/user -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-logout" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                           <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                           <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2"></path>
                           <path d="M9 12h12l-3 -3"></path>
                           <path d="M18 15l3 -3"></path>
                        </svg>
                        </span>
                            {{ __('Log Out') }}
                        </x-nav-link>
                    </form>
                </li>


            </ul>
        </div>
    </div>
</aside>
