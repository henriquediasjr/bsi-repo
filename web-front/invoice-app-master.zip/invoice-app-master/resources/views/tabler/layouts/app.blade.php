<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['node_modules/@tabler/core/src/scss/tabler.scss', 'resources/js/app.js'])
    </head>
    <body class="font-sans">

    <div class="page">

        <!-- Sidebar -->
        @include('layouts.navigation')

        @include('layouts.navbar')

        <div class="page-wrapper">

            <!-- Page Heading -->
            @if (isset($header))
                {{$header}}
            @endif

            <!-- Page body -->
            <div class="page-body">
                <div class="container-xl">
                {{ $slot }}
                </div>
            </div>

            <footer class="footer footer-transparent d-print-none">
                <div class="container-xl">
                    <div class="row text-center align-items-center flex-row-reverse">
                        <div class="col-lg-auto ms-lg-auto">
                            <ul class="list-inline list-inline-dots mb-0">
                                <li class="list-inline-item">
                                    <small>Desenvolvido por <a href="https://inuartech.com" class="link-secondary" rel="noopener">Inuar</a> utilizando Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})</small>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    </body>
</html>
