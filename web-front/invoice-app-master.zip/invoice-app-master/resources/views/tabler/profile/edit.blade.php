<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{ __('Overview') }}
                        </div>
                        <h2 class="page-title">
                            {{ __('Profile') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>
    {{--<div class="row row-cards">--}}
        {{--<div class="col-12">--}}
            {{--<form method="post" action="{{ route('profile.store', ['company' => $company]) }}" class="card ">--}}

                {{--<div class="card-footer text-end">--}}
                    {{--<a href="{{route('profile.edit')}}" class="btn btn-link">Cancel</a>--}}
                    {{--<x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>--}}
                {{--</div>--}}
            {{--</form>--}}
        {{--</div>--}}
    {{--</div>--}}


    <div class="row row-cards">
        <div class="col-12">
            <form method="post" action="{{ route('profile.update') }}" class="card">
                @csrf
                @method('patch')
                    @include('profile.partials.update-profile-information-form')
                    @include('profile.partials.company-edit', ['company' => $company])
            </form>
        </div>

        <div class="col-12">
            @include('profile.partials.update-password-form')
        </div>

        <div class="col-12">
            @include('profile.partials.delete-user-form')
        </div>
    </div>

</x-app-layout>
