
<div class="row row-cards">
    <div class="col-12">
        <div class="card-body">
            <h3 class="card-title">{{ __('Company Information') }}</h3>
            <div class="mb-3">
                <div>
                    {{ __("Update your account's profile information and email address.") }}
                </div>
            </div>
            <div class="row row-cards">

                <x-text-input id="company_id" name="company_id" type="hidden" class="mt-1 form-control block w-full {{$errors->has('company_id') ? 'is-invalid' : '' }}" :value="old('id', $company->id)"  autofocus autocomplete="company_id" />

                <div class="col-md-6">
                    <div class="mb-3">

                        <x-input-label class="form-label required" for="company_name" :value="__('Company Name')" />
                        <x-text-input id="company_name" name="company_name" type="text" class="mt-1 form-control block w-full {{$errors->has('company_company_name') ? 'is-invalid' : '' }}" :value="old('company_name', $company->name)" autofocus autocomplete="company_name" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_company_name')" />

                    </div>
                </div>
                <div class="col-md-12">
                    <hr>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <x-input-label for="company_email" :value="__('Email')" />
                        <x-text-input id="company_email" name="company_email" type="text" class="mt-1 form-control block w-full {{$errors->has('company_email') ? 'is-invalid' : '' }}" :value="old('email', $company->email)" autofocus autocomplete="company_email" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_email')" />
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <x-input-label for="company_phone" :value="__('Phone Number')" />
                        <x-text-input id="company_phone" name="company_phone" type="text" class="mt-1 form-control block w-full {{$errors->has('company_phone') ? 'is-invalid' : '' }}" :value="old('phone', $company->phone)" autofocus autocomplete="company_phone" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_phone')" />
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="mb-3">
                        <x-input-label for="company_address" :value="__('Address')" />
                        <x-text-input id="company_address" name="company_address" type="text" class="mt-1 form-control block w-full {{$errors->has('company_address') ? 'is-invalid' : '' }}" :value="old('address', $company->address)" autofocus autocomplete="company_address" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_address')" />
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="mb-3">
                        <x-input-label for="company_address_number" :value="__('Address Number')" />
                        <x-text-input id="company_address_number" name="company_address_number" type="text" class="mt-1 form-control block w-full {{$errors->has('company_address_number') ? 'is-invalid' : '' }}" :value="old('address_number', $company->address_number)" autofocus autocomplete="company_address_number" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_address_number')" />
                    </div>
                </div>
                <div class="col-sm-6 col-md-3">
                    <div class="mb-3">
                        <x-input-label for="company_address_complement" :value="__('Address Complement')" />
                        <x-text-input id="company_address_complement" name="company_address_complement" type="text" class="mt-1 form-control block w-full {{$errors->has('company_address_complement') ? 'is-invalid' : '' }}" :value="old('address_complement', $company->address_complement)" autofocus autocomplete="company_address_complement" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_address_complement')" />
                    </div>
                </div>
                <div class="col-sm-6 col-md-2">
                    <div class="mb-3">
                        <x-input-label for="company_address_cep" :value="__('CEP')" />
                        <x-text-input id="company_address_cep" name="company_address_cep" type="text" class="mt-1 form-control block w-full {{$errors->has('company_address_cep') ? 'is-invalid' : '' }}" :value="old('address_cep', $company->address_cep)" autofocus autocomplete="company_address_cep" />
                        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('company_address_cep')" />
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-end">
            <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>

            @if (session('status') === 'profile-updated')
                <p
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        class="text-sm text-gray-600 dark:text-gray-400"
                >{{ __('Saved.') }}</p>
            @endif
        </div>
    </div>
</div>