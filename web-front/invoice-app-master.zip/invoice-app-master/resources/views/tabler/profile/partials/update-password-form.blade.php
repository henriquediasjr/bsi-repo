<form method="post" action="{{ route('password.update') }}" class="card">
    @csrf
    @method('put')

    <div class="card-body">
        <h3 class="card-title">{{ __('Update Password') }}</h3>
        <div class="mb-3">
            <div>
                {{ __('Ensure your account is using a long, random password to stay secure.') }}
            </div>
        </div>
        <div class="col-md-5">
            <div class="mb-3">
                <x-input-label for="current_password" :value="__('Current Password')" />
                <x-text-input id="current_password" name="current_password" type="password" class="mt-1 block w-full {{$errors->updatePassword->get('current_password') ? 'is-invalid' : '' }}" autocomplete="current-password" />
                <x-input-error :messages="$errors->updatePassword->get('current_password')" class="invalid-feedback mt-2" />

            </div>
        </div>

        <div class="col-md-5">
            <div class="mb-3">
                <x-input-label for="password" :value="__('New Password')" />
                <x-text-input id="password" name="password" type="password" class="mt-1 block w-full {{$errors->updatePassword->get('password') ? 'is-invalid' : '' }}" autocomplete="new-password" />
                <x-input-error :messages="$errors->updatePassword->get('password')" class="invalid-feedback mt-2" />
            </div>
        </div>

        <div class="col-md-5">
            <div class="mb-3">
                <x-input-label for="password_confirmation" :value="__('Confirm Password')" />
                <x-text-input id="password_confirmation" name="password_confirmation" type="password" class="mt-1 block w-full" autocomplete="new-password" />
                <x-input-error :messages="$errors->updatePassword->get('password_confirmation')" class="mt-2" />
            </div>
        </div>
    </div>
    <div class="card-footer text-end">
        <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>
        @if (session('status') === 'password-updated')
            <p
                x-data="{ show: true }"
                x-show="show"
                x-transition
                x-init="setTimeout(() => show = false, 2000)"
                class="text-sm text-gray-600 dark:text-gray-400"
            >{{ __('Saved.') }}</p>
        @endif

    </div>
</form>
