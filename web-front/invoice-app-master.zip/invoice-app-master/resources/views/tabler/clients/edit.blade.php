<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Edit Client') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">

            <form method="post" action="{{ route('clients.update', ['client' => $client]) }}" class="card ">
                @csrf
                @method("PATCH")

                <div class="card-body">
                    <h3 class="card-title">{{ __('Client information') }}</h3>
                    <div class="mb-3">
                        <div>
                            {{ __("Edit client data.") }}
                        </div>
                    </div>

                    <div class="row row-cards">
                        @include('clients._form', ['client' => $client])
                    </div>



                </div>
                <div class="card-footer text-end">
                    <a href="{{route('clients.index')}}" class="btn btn-link">Cancel</a>
                    <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>
                </div>
            </form>

        </div>


    </div>

</x-app-layout>
