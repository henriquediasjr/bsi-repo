
<div class="col-md-4">
    <div class="mb-3">

        <x-input-label for="id" :value="__('ID')" />
        <x-text-input id="id" name="id" type="text" class="mt-1 form-control disabled block w-full {{$errors->has('id') ? 'is-invalid' : '' }}" :value="old('id', $client->id)" disabled="disabled" autofocus autocomplete="id" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('id')" />

    </div>
</div>


<div class="col-md-6">
    <div class="mb-3">

        <x-input-label class="form-label required" for="name" :value="__('Company Name')" />
        <x-text-input id="name" name="name" type="text" class="mt-1 form-control block w-full {{$errors->has('name') ? 'is-invalid' : '' }}" :value="old('name', $client->name)" autofocus autocomplete="name" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('name')" />

    </div>
</div>

<div class="col-md-12">
    <hr>
</div>

<div class="col-md-6">
    <div class="mb-3">
        <x-input-label for="phone" :value="__('Phone Number')" />
        <x-text-input id="phone" name="phone" type="text" class="mt-1 form-control block w-full {{$errors->has('phone') ? 'is-invalid' : '' }}" :value="old('phone', $client->phone)" autofocus autocomplete="phone" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('phone')" />
    </div>
</div>

<div class="col-md-6">
    <div class="mb-3">
        <x-input-label for="address" :value="__('Address')" />
        <x-text-input id="address" name="address" type="text" class="mt-1 form-control block w-full {{$errors->has('address') ? 'is-invalid' : '' }}" :value="old('address', $client->address)" autofocus autocomplete="address" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('address')" />
    </div>
</div>
<div class="col-sm-6 col-md-3">
    <div class="mb-3">
        <x-input-label for="address_number" :value="__('Address Number')" />
        <x-text-input id="address_number" name="address_number" type="text" class="mt-1 form-control block w-full {{$errors->has('address_number') ? 'is-invalid' : '' }}" :value="old('address_number', $client->address_number)" autofocus autocomplete="address_number" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('address_number')" />
    </div>
</div>
<div class="col-sm-6 col-md-3">
    <div class="mb-3">
        <x-input-label for="address_complement" :value="__('Address Complement')" />
        <x-text-input id="address_complement" name="address_complement" type="text" class="mt-1 form-control block w-full {{$errors->has('address_complement') ? 'is-invalid' : '' }}" :value="old('address_complement', $client->address_complement)" autofocus autocomplete="address_complement" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('address_complement')" />
    </div>
</div>

<div class="col-sm-6 col-md-2">
    <div class="mb-3">
        <x-input-label for="address_cep" :value="__('CEP')" />
        <x-text-input id="address_cep" name="address_cep" type="text" class="mt-1 form-control block w-full {{$errors->has('address_cep') ? 'is-invalid' : '' }}" :value="old('address_cep', $client->address_cep)" autofocus autocomplete="address_cep" />
        <x-input-error class="invalid-feedback mt-2" :messages="$errors->get('address_cep')" />
    </div>
</div>