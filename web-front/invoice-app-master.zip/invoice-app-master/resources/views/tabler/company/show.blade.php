<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Show Company') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>


    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">{{__('Company info')}}</h3>
            </div>
            <div class="card-body">
                <div class="datagrid">
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Name')}}</div>
                        <div class="datagrid-content">{{$company->name}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Creation date')}}</div>
                        <div class="datagrid-content">
                            <nospan>{{ \Carbon\Carbon::parse($company->created_at)->format('d/m/Y H:i')}}</nospan>
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Member since')}}</div>
                        <div class="datagrid-content">15 {{__('days')}}</div>
                    </div>

                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Company Phone')}}</div>
                        <div class="datagrid-content">
                            {{$company->phone}}
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('country')}}</div>
                        <div class="datagrid-content">
                            {{$company->country}}
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Company Address')}}</div>
                        <div class="datagrid-content">
                            {{$company->address}}
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Company Address Number')}}</div>
                        <div class="datagrid-content">
                            {{$company->address_number}}
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Company Address Complement')}}</div>
                        <div class="datagrid-content">
                            {{$company->address_complement}}
                        </div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Company CEP')}}</div>
                        <div class="datagrid-content">
                            {{$company->address_cep}}
                        </div>
                    </div>


                </div>
            </div>
            <div class="card-footer text-end">
                <a href="{{route('companies.index')}}" class="btn btn-link">Cancel</a>

                @can('edit company')
                <x-secondary-button class="btn">
                    <a href="{{route('companies.edit', ['company' => $company->id])}}">Editar</a>
                </x-secondary-button>
                @endcan

            </div>
        </div>

    </div>


</x-app-layout>
