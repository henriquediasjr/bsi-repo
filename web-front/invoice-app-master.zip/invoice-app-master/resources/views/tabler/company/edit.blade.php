<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Edit Company') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">

            <form method="post" action="{{ route('companies.update', ['company' => $company]) }}" class="card ">
                @csrf
                @method("PATCH")

                <div class="card-body">
                    <h3 class="card-title">{{ __('Company information') }}</h3>
                    <div class="mb-3">
                        <div>
                            {{ __("Edit company data.") }}
                        </div>
                    </div>

                    <div class="row row-cards">
                        @include('company._form', ['company' => $company])
                    </div>



                </div>
                <div class="card-footer text-end">
                    <a href="{{route('companies.index')}}" class="btn btn-link">Cancel</a>
                    <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>
                </div>
            </form>

        </div>


    </div>

</x-app-layout>
