<x-app-layout>
    <x-slot name="header">

        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{ __('Overview') }}
                        </div>
                        <h2 class="page-title">
                            {{ __('Dashboard') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Page title actions -->
            <div class="col-auto ms-auto d-print-none">
                <div class="btn-list">
                    <a href="{{route('invoices.create')}}" class="btn btn-primary d-none d-sm-inline-block">
                        <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                        {{ __('Create invoice') }}
                    </a>
                    <a href="{{route('invoices.create')}}" class="btn btn-primary d-sm-none btn-icon"  aria-label="Create new report">
                        <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                    </a>
                </div>
            </div>


    </x-slot>

    <div class="container">
        <h2>{{__('Recent Invoices')}}</h2>
        <div class="row row-cards">
            @foreach($invoices as $invoice)
                <a href="{{ route('invoices.show', ['invoice' => $invoice->id]) }}" class="col-sm-6 col-lg-3 text-decoration-none">
                    <div class="card">
                        <div class="card-title">
                            <h3 class="text-center">Future Logo</h3>
                        </div>
                        <div class="card-body">
                            <h3 class="text-center">Total <br><span>R${{$invoice->subtotal}}</span></h3>
                            <div class="card-text">
                                <span>{{__('Invoice')}}: {{$invoice->id}}</span> <br>
                                <span>{{__('Issue Date')}}: {{$invoice->issue_date}}</span>
                            </div>
                        </div>
                    </div>

                </a>

            @endforeach
        </div>

    </div>

    <div class="page-body">
        <div class="container-xl">
            <div class="card card-lg">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <p class="h3">Company</p>
                            <address>
                                Street Address<br>
                                State, City<br>
                                Region, Postal Code<br>
                                ltd@example.com
                            </address>
                        </div>
                        <div class="col-6 text-end">
                            <p class="h3">Client</p>
                            <address>
                                Street Address<br>
                                State, City<br>
                                Region, Postal Code<br>
                                ctr@example.com
                            </address>
                        </div>
                        <div class="col-12 my-5">
                            <h1>Invoice INV/001/15</h1>
                        </div>
                    </div>
                    <table class="table table-transparent table-responsive">
                        <thead>
                        <tr>
                            <th class="text-center" style="width: 1%"></th>
                            <th>Product</th>
                            <th class="text-center" style="width: 1%">Qnt</th>
                            <th class="text-end" style="width: 1%">Unit</th>
                            <th class="text-end" style="width: 1%">Amount</th>
                        </tr>
                        </thead>
                        <tbody><tr>
                            <td class="text-center">1</td>
                            <td>
                                <p class="strong mb-1">Logo Creation</p>
                                <div class="text-secondary">Logo and business cards design</div>
                            </td>
                            <td class="text-center">
                                1
                            </td>
                            <td class="text-end">$1.800,00</td>
                            <td class="text-end">$1.800,00</td>
                        </tr>
                        <tr>
                            <td class="text-center">2</td>
                            <td>
                                <p class="strong mb-1">Online Store Design &amp; Development</p>
                                <div class="text-secondary">Design/Development for all popular modern browsers</div>
                            </td>
                            <td class="text-center">
                                1
                            </td>
                            <td class="text-end">$20.000,00</td>
                            <td class="text-end">$20.000,00</td>
                        </tr>
                        <tr>
                            <td class="text-center">3</td>
                            <td>
                                <p class="strong mb-1">App Design</p>
                                <div class="text-secondary">Promotional mobile application</div>
                            </td>
                            <td class="text-center">
                                1
                            </td>
                            <td class="text-end">$3.200,00</td>
                            <td class="text-end">$3.200,00</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Subtotal</td>
                            <td class="text-end">$25.000,00</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Vat Rate</td>
                            <td class="text-end">20%</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Vat Due</td>
                            <td class="text-end">$5.000,00</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="font-weight-bold text-uppercase text-end">Total Due</td>
                            <td class="font-weight-bold text-end">$30.000,00</td>
                        </tr>
                        </tbody></table>
                    <p class="text-secondary text-center mt-5">Thank you very much for doing business with us. We look forward to working with
                        you again!</p>
                </div>
            </div>
        </div>
    </div>


</x-app-layout>
