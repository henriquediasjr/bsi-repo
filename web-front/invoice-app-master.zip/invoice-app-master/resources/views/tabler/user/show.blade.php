<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Show User') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>


    <div class="row row-cards">

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">{{__('User info')}}</h3>
            </div>
            <div class="card-body">
                <div class="datagrid">
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Name')}}</div>
                        <div class="datagrid-content">{{$user->name}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Email')}}</div>
                        <div class="datagrid-content">{{$user->email}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Creation date')}}</div>
                        <div class="datagrid-content">{{$user->created_at}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Updated date')}}</div>
                        <div class="datagrid-content">{{$user->updated_at}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Member since')}}</div>
                        <div class="datagrid-content">15 {{__('days')}}</div>
                    </div>
                    <div class="datagrid-item">
                        <div class="datagrid-title">Status</div>
                        <div class="datagrid-content">
                            <x-status-badge status="{{$user->status}}"/>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer text-end">
                <a href="{{route('users.index')}}" class="btn btn-link">{{__('Cancel')}}</a>

                @can('edit user')
                <x-secondary-button class="btn">
                    <a href="{{route('users.edit', ['user' => $user->id])}}">{{__('Edit')}}</a>
                </x-secondary-button>
                @endcan

            </div>
        </div>

    </div>

</x-app-layout>
