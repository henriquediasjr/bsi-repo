<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Create User') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">

            <form method="post" action="{{ route('users.store') }}" class="card">
                @csrf

                <div class="card-body">
                    <h3 class="card-title">{{ __('User information') }}</h3>
                    <div class="mb-3">
                        <div>
                            {{ __("Update your account's profile information and email address.") }}
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="mb-3">
                            <x-input-label for="name" :value="__('Name')" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name')" required autofocus autocomplete="name" />
                            <x-input-error class="mt-2" :messages="$errors->get('name')" />

                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="mb-3">
                            <x-input-label for="email" :value="__('Email')" />
                            <x-text-input id="email" name="email" type="email" class="mt-1 block w-full" :value="old('email')" required autocomplete="username" />
                            <x-input-error class="mt-2" :messages="$errors->get('email')" />
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="mb-3">
                            <x-input-label for="password" :value="__('Password')" />
                            <x-text-input id="password" name="password" type="password" class="mt-1 block w-full" autocomplete="new-password" />
                            <x-input-error :messages="$errors->password->get('password')" class="mt-2" />
                        </div>
                    </div>
                </div>
                <div class="card-footer text-end">
                    <a href="{{route('users.index')}}" class="btn btn-link">{{__('Cancel')}}</a>

                    <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>

                    @if (session('status') === 'profile-updated')
                        <p
                            x-data="{ show: true }"
                            x-show="show"
                            x-transition
                            x-init="setTimeout(() => show = false, 2000)"
                            class="text-sm text-gray-600 dark:text-gray-400"
                        >{{ __('Saved.') }}</p>
                    @endif
                </div>
            </form>

        </div>

    </div>

</x-app-layout>
