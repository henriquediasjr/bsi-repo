<x-app-layout>
    <x-slot name="header">

        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{ __('Overview') }}
                        </div>
                        <h2 class="page-title">
                            {{ __('List Users') }}
                        </h2>
                    </div>

                    @can('add user')
                    <!-- Page title actions -->
                    <div class="col-auto ms-auto d-print-none">
                        <div class="btn-list">
                            <a href="{{route('users.create')}}" class="btn btn-primary d-none d-sm-inline-block">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                                {{ __('Create user') }}
                            </a>
                            <a href="{{route('users.create')}}" class="btn btn-primary d-sm-none btn-icon"  aria-label="Create new report">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                            </a>
                        </div>
                    </div>
                    @endcan

                </div>
            </div>
        </div>
    </x-slot>


    <div class="row row-cards" id="app">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">
            <div class="card">
                    <form action="{{ route('users.index') }}" method="get" name="users" id="searchUser">

                    <div class="card-body border-bottom py-3">

                        <div class="d-flex flex-column flex-sm-row justify-content-between">

                            <div class="mb-2 mb-sm-0">
                                <max-results limit="{{$filters['limit']}}"></max-results>
                            </div>

                            <div class="ms-md-auto text-muted">
                                <div class="row g-2">
                                    <div class="col">
                                        <input type="text" id="searchButton" name="search" placeholder="pesquisar por..." class="form-control" aria-label="Search user"  value="{{ request('search') }}">
                                    </div>
                                    <div class="col-auto">
                                        <a href="#" onclick="document.getElementById('searchUser').submit();" class="btn btn-icon" aria-label="{{ __('Search') }}">
                                            <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"></path><path d="M21 21l-6 -6"></path></svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <more-filters status="{{$filters['status']}}" opened="{{$filters['status'] > 0}}"></more-filters>

                    </div>

                    </form>
                @if(count($users) < 1)
                    <div class="card-body border-bottom">
                        <h1> {{__('No results found.')}}</h1>
                    </div>

                @else
                    <div class="table-responsive">
                        <table class="table card-table table-vcenter text-nowrap datatable">
                            <thead>
                            <tr>
                                <th class="d-none d-md-table-cell"><checkbox-all> </checkbox-all></th>
                                <th class="d-none d-md-table-cell">
                                    <order-by name="ID" value="id" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th>
                                    <order-by name="Nome" value="name" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="d-none d-md-table-cell">
                                    <order-by name="E-mail" value="email" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="d-none d-md-table-cell">
                                    <order-by name="Criado em" value="created_at" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th>
                                    <order-by name="Status" value="status" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="w-1 d-none d-md-table-cell"></th>
                            </tr>
                            </thead>

                            <tbody>
                            @foreach($users as $key => $user)
                            <tr>
                                <td class="d-none d-md-table-cell"><user-checkbox user-id="{{$user->id}}"></user-checkbox></td>
                                <td class="d-none d-md-table-cell"><span class="text-muted">

                                <a href="{{ route('users.show', ['user' => $user->id]) }}" >
                                    {{$user->id}}
                                </a>

                                </span></td>
                                <td><a href="{{ route('users.show', ['user' => $user->id]) }}" class="text-reset" tabindex="-1">{{$user->name}}</a></td>
                                <td class="d-none d-md-table-cell">
                                    <span class="text-muted">
                                    {{$user->email}}
                                    </span>
                                </td>
                                <td class="d-none d-md-table-cell">
                                    <span class="text-muted">
                                        <nospan>{{ \Carbon\Carbon::parse($user->created_at)->format('d/m/Y H:i')}}</nospan>
                                    </span>
                                </td>
                                <td>
                                    <x-status-badge status="{{$user->status}}"/>
                                </td>
                                <td class="w-1  text-end d-none d-md-table-cell">
                                    <div class="btn-list flex-nowrap">

                                        @can('edit user')
                                        <a href="{{ route('users.edit', ['user' => $user->id]) }}" class="btn">
                                            {{ __('Edit') }}
                                        </a>
                                        @endcan

                                        @can('delete user')
                                            <x-delete-user-button user="{{$user->id}}" data-bs-toggle="modal" data-bs-target="#delete-modal-{{$user->id}}" class="d-none d-md-inline">{{ __('Delete') }}</x-delete-user-button>
                                        @endcan

                                    </div>
                                </td>
                            </tr>
                            @endforeach

                            <tr>
                                <td class="text-end" colspan="7">
                                    <bulk-actions></bulk-actions>
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                           {{$users->links()}}
                    </div>
                @endif
            </div>
        </div>
        @if(count($users) > 0)
            <div class="modal" id="delete-modal" tabindex="-1">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <div class="modal-body text-center py-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M12 9v2m0 4v.01" />
                            <path d="M5 19h14a2 2 0 0 0 1.84 -2.75l-7.1 -12.25a2 2 0 0 0 -3.5 0l-7.1 12.25a2 2 0 0 0 1.75 2.75" />
                        </svg>
                        <h3>{{__('Are you sure?')}}</h3>
                        <div class="text-muted">{{__('Do you want to delete this user?')}}</div>
                    </div>

                    <div class="modal-footer">
                        <div class="w-100">
                            <div class="row">
                                <div class="col"><a href="#" class="btn w-100" data-bs-dismiss="modal">
                                        {{__('Cancel')}}
                                    </a></div>
                                <form id="delete-form" method="POST" class="col" action="{{ route('users.destroy', ['user' => $user->id]) }}">
                                    @csrf
                                    @method('delete')
                                    <x-danger-button class="btn w-100">{{ __('Delete') }}</x-danger-button>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        @endif

    </div>

</x-app-layout>
