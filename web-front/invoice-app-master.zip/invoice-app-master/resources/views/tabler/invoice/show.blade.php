<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{__('Overview')}}
                        </div>
                        <h2 class="page-title">
                            {{ __('Show Invoice') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="page-body">
        <div class="container-xl">
            <div class="card card-lg">
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-8">
                           <div class="btn btn-disabled" style="width: 60%; height: 100%">
                               <h2>Logo</h2>
                           </div>
                        </div>
                        <div class="col-4 text-end">

                            <label class="form-label text-start">{{ __('Issue Date') }}</label>
                            <input type="text" name="input-mask" class="form-control" data-mask="0000/00/00"
                                   data-mask-visible="true" placeholder="0000/00/00" autocomplete="off" value="{{$invoice->issue_date}}">

                            <label class="form-label text-start">{{ __('due Date') }}</label>
                            <input type="text" name="input-mask" class="form-control" data-mask="0000/00/00"
                                   data-mask-visible="true" placeholder="0000/00/00" autocomplete="off" value="{{$invoice->due_date}}">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <h3>{{__('Company')}}</h3>
                            <p class="h3">{{$invoice->company->name}}</p>
                            <address>
                                {{$invoice->company->address}}<br>
                                {{$invoice->company->address_number}}<br>
                                {{$invoice->company->address_complement}}<br>
                                {{$invoice->company->country}}<br>
                                {{$invoice->company->city}}, {{$invoice->company->cep}}<br>
                                {{$invoice->company->email}}
                            </address>
                        </div>
                        <div class="col-6 text-end">
                            <h3>{{__('Client')}}</h3>
                            <p class="h3">{{$invoice->client->name}}</p>
                            <address>
                                {{$invoice->client->address}}<br>
                                {{$invoice->client->address_number}}<br>
                                {{$invoice->client->address_complement}}<br>
                                {{$invoice->client->country}}<br>
                                {{$invoice->client->city}}, {{$invoice->client->cep}}<br>
                                {{$invoice->client->email}}
                            </address>
                        </div>
                        <div class="col-12 my-5">
                            <h1>{{$invoice->title}}</h1>
                        </div>
                    </div>
                    <table class="table table-transparent table-responsive">
                        <thead>
                        <tr>
                            <th class="text-center" style="width: 1%"></th>
                            <th>Product</th>
                            <th class="text-center" style="width: 1%">Qnt</th>
                            <th class="text-end" style="width: 1%">Unit</th>
                            <th class="text-end" style="width: 1%">Amount</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($invoice->invoiceItems as $item)
                            <tr>
                                <td class="text-center">1</td>
                                <td>
                                    <p class="strong mb-1">{{$item->title}}</p>
                                    <div class="text-secondary">{{$item->description}}</div>
                                </td>
                                <td class="text-center">
                                    {{$item->quantity}}
                                </td>
                                <td class="text-end">{{Str::currency($item->unit)}}</td>
                                <td class="text-end">{{Str::currency($item->amount)}}</td>
                            </tr>
                        @endforeach
                        <tr>
                            <td colspan="4" class="strong text-end">Subtotal</td>
                            <td class="text-end">{{$invoice->subtotal}}</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Vat Rate</td>
                            <td class="text-end">20%</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Vat Due</td>
                            <td class="text-end">$5.000,00</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="font-weight-bold text-uppercase text-end">Total Due</td>
                            <td class="font-weight-bold text-end">$30.000,00</td>
                        </tr>
                        </tbody></table>
                    <p class="text-secondary text-center mt-5">Thank you very much for doing business with us. We look forward to working with
                        you again!</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">{{__('Invoice info')}}</h3>
            </div>
            <div class="card-body">
                <div class="datagrid">
                    <div class="datagrid-item">
                        <div class="datagrid-title">{{__('Title')}}</div>
                        <div class="datagrid-content">{{$invoice->title}}</div>
                    </div>

                </div>
            </div>
            <div class="card-footer text-end">
                <a href="{{route('invoices.index')}}" class="btn btn-link">Cancel</a>

                @can('edit invoice')
                <x-secondary-button class="btn">
                    <a href="{{route('invoices.edit', ['invoice' => $invoice->id])}}">Editar</a>
                </x-secondary-button>
                @endcan

            </div>
        </div>

    </div>

</x-app-layout>
