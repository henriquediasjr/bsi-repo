<x-app-layout>
    <x-slot name="header">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{ __('Overview') }}
                        </div>
                        <h2 class="page-title">
                            {{ __('Create Company') }}
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </x-slot>

    <div class="row row-cards">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">

            <form method="post" action="{{ route('companies.store') }}" class="card">
                @csrf

                <div class="card-body">
                    <h3 class="card-title">{{ __('Company information') }}</h3>
                    <div class="mb-3">
                        <div>
                            {{ __("Update your account's profile information and email address.") }}
                        </div>
                    </div>

                    <div class="row row-cards">
                        @include('company._form', ['company' => $company, 'states' => $states, 'cities' => $cities, 'partners' => $partners, 'serviceCategories' => $serviceCategories])
                    </div>

                </div>
                <div class="card-footer text-end">
                    <a href="{{route('companies.index')}}" class="btn btn-link">Cancel</a>

                    <x-primary-button class="btn btn-primary">{{ __('Save') }}</x-primary-button>

                    @if (session('status') === 'profile-updated')
                        <p
                            x-data="{ show: true }"
                            x-show="show"
                            x-transition
                            x-init="setTimeout(() => show = false, 2000)"
                            class="text-sm text-gray-600 dark:text-gray-400"
                        >{{ __('Saved.') }}</p>
                    @endif
                </div>
            </form>

        </div>

    </div>

</x-app-layout>
