<x-app-layout>
    <x-slot name="header">

        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            {{ __('Overview') }}
                        </div>
                        <h2 class="page-title">
                            {{ __('List Invoices') }}
                        </h2>
                    </div>

                    @can('add invoice')
                    <!-- Page title actions -->
                    <div class="col-auto ms-auto d-print-none">
                        <div class="btn-list">
                            <a href="{{route('invoices.create')}}" class="btn btn-primary d-none d-sm-inline-block">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                                {{ __('Create invoice') }}
                            </a>
                            <a href="{{route('invoices.create')}}" class="btn btn-primary d-sm-none btn-icon"  aria-label="Create new report">
                                <!-- Download SVG icon from http://tabler-icons.io/i/plus -->
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M12 5l0 14" /><path d="M5 12l14 0" /></svg>
                            </a>
                        </div>
                    </div>
                    @endcan

                </div>
            </div>
        </div>
    </x-slot>


    <div class="row row-cards" id="app">

        <div class="col-12">
            @include('flash-message')
        </div>

        <div class="col-12">
            <div class="card">
                    <form action="{{ route('invoices.index') }}" method="get" name="users" id="searchCompany">

                    <div class="card-body border-bottom py-3">

                        <div class="d-flex flex-column flex-sm-row justify-content-between">

                            <div class="mb-2 mb-sm-0">
                                <max-results limit="{{$filters['limit']}}"></max-results>
                            </div>

                            <div class="ms-md-auto text-muted">
                                <div class="row g-2">
                                    <div class="col">
                                        <input type="text" id="searchButton" name="search" placeholder="pesquisar por..." class="form-control" aria-label="Search user"  value="{{ request('search') }}">
                                    </div>
                                    <div class="col-auto">
                                        <a href="#" onclick="document.getElementById('searchCompany').submit();" class="btn btn-icon" aria-label="{{ __('Search') }}">
                                            <!-- Download SVG icon from http://tabler-icons.io/i/search -->
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"></path><path d="M21 21l-6 -6"></path></svg>
                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <a href="{{route('invoices.export')}}?{{request()->getQueryString()}}" class="btn btn-icon" aria-label="{{ __('Export') }}">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-file-cv" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M14 3v4a1 1 0 0 0 1 1h4"></path>
                                                <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z"></path>
                                                <path d="M11 12.5a1.5 1.5 0 0 0 -3 0v3a1.5 1.5 0 0 0 3 0"></path>
                                                <path d="M13 11l1.5 6l1.5 -6"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                    </form>
                @if(count($invoices) < 1)
                    <div class="card-body border-bottom">
                        <span>{{__('No results found.')}}</span>
                    </div>

                @else
                    <div class="table-responsive">
                        <table class="table card-table table-vcenter datatable">
                            <thead>
                            <tr>
                                <th class="w-1 d-none d-md-table-cell"><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select all"></th>
                                <th class="w-1 d-none d-md-table-cell">#
                                    <order-by name="ID" value="invoices.id" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th>
                                    <order-by name="Nome" value="clients.name" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="d-none d-md-table-cell">
                                </th>
                                <th class="d-none d-md-table-cell">
                                    <order-by name="Criado em" value="invoices.created_at" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="w-1 ">
                                    <order-by name="Status" value="invoices.title" order="{{$filters['order']}}" dir="{{$filters['orderDir']}}"></order-by>
                                </th>
                                <th class="w-1 d-none d-md-table-cell"></th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($invoices as $key => $invoice)
                            <tr>
                                <td class="d-none d-md-table-cell">
                                    <input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select">
                                </td>
                                <td class="d-none d-md-table-cell">
                                    <span class="text-muted">
                                    <a href="{{ route('invoices.show', ['invoice' => $invoice->id]) }}" >
                                        {{$invoice->id}}
                                    </a>
                                </span></td>
                                <td>
                                    <a href="{{ route('invoices.show', ['invoice' => $invoice->id]) }}" class="text-reset" tabindex="-1" >
                                        {{$invoice->client->name}} / (company: {{$invoice->company->name}})
                                    </a>
                                </td>

                                <td class="d-none d-md-table-cell">
                                    <nospan>{{ \Carbon\Carbon::parse($invoice->created_at)->format('d/m/Y H:i')}}</nospan>
                                </td>
                                <td class="">
                                </td>
                                <td class="text-end d-none d-md-table-cell">
                                    <div class="btn-list flex-nowrap">

                                        @can('edit invoice')
                                        <a href="{{ route('invoices.edit', ['invoice' => $invoice->id]) }}" class="btn">
                                            {{ __('Edit') }}
                                        </a>
                                        @endcan

                                        @can('delete invoice')
                                        <x-delete-invoice-button invoice="{{$invoice->id}}" data-bs-toggle="modal" data-bs-target="#delete-modal-{{$invoice->id}}" class="d-none d-md-inline">{{ __('Delete') }}</x-delete-invoice-button>
                                        @endcan

                                    </div>
                                </td>
                            </tr>
                            @endforeach

                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                           {{$invoices->links()}}
                    </div>
                @endif
            </div>
        </div>


        </div>

</x-app-layout>
