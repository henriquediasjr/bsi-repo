import UserCheckBox from "./UserCheckBox";

export default{
    components:{
        UserCheckBox
    },

    template:`
            <div class="btn-list flex-nowrap" v-show="select"> 
                <x-danger-button class="btn btn-danger text-end">delete</x-danger-button>
            </div>
    `,

    data() {
        return {
            select: false,
            inputId: []
        }
    },

    methods: {
        handleSelected(selectId) {
            this.inputId.push(selectId);
        }
    },

    mounted() {
        this.emitter.on('select-all-changed', (data) => {
            this.select = data
        });

        this.emitter.on('input-id-selected', (data) => {
            this.handleSelected(data);
    });
    }

}