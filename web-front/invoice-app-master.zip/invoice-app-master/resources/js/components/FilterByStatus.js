export default {
    props: ['status'],
    template:`
        <div class="text-muted text-nowrap">
            Filtrar por status
            <div class="ms-2 d-inline-block">

                <select v-model="status" name="status" id="status" class="form-select" @change="postEvent()">
                    <option v-for="option in options" :key="option.value" :value="option.value">
                        {{ option.label }}
                    </option>
                </select>
            </div>
        </div>
    `,

    data() {
        return {
            options: [
                { value: 0, label: 'Todos' },
                { value: 1, label: 'Ativos'},
                { value: 2, label: 'Inativos'},
            ],
        }
    },

    methods: {
        postEvent: function(){
            document.forms['users'].submit()
        }
    }
}
