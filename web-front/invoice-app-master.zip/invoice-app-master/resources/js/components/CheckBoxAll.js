export default {

    template:` 
        <input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select all invoices" v-model="selected" @change="selectAll">    
    `,

    data() {
        return {
            selected: false
        }
    },

    methods: {
        selectAll() {
            this.emitter.emit("select-all-changed", this.selected)
            // this.$emit('select-all-changed', this.selected);
        }
    }

}
