import Logo from "./invoice/Logo";
import IssueDate from "./invoice/IssueDate";
import DueDate from "./invoice/DueDate";
import Client from "./invoice/Client";
import Company from "./invoice/Company";
import InvoiceItems from "./invoice/InvoiceItems";
import ClientModal from "./invoice/ClientModal";
import CompanyModal from "./invoice/CompanyModal";
import '../invoice-edit.css';
import axios from "axios";
import { useToast } from 'vue-toastification';


export default{
    props: [
        'invoice',
        'clients',
        'companies',
    ],

    template:`
        <label for="mode" class="mr-2">Editar</label>
        <input id="mode" type="checkbox" v-model="invoiceMode">
        <div class="card card-lg">
            <div class="card-body">
                <div class="row mb-4">
                    <div class="col-8" :class="invoiceMode ? 'border-custom' : ''">
                       <Logo></Logo>
                    </div>
                    <div class="col-4 text-end">                        
                       <IssueDate @updateIssue="updateIssue" :issueDate="issueDate" :invoiceMode="invoiceMode"></IssueDate>
                       <DueDate @updateDue="updateDue" :dueDate="dueDate" :invoiceMode="invoiceMode"></DueDate>
                    </div>
                </div> 
                <div class="row">
                    <div v-if="!invoiceMode" class="col-6" :class="{'border-custom' : invoiceMode}" >
                        <Client :clientInfo="clientInfo"></Client>
                    </div>
                    <div v-else class="col-6" :class="{'border-custom' : invoiceMode}" @click="openClientModal = !openClientModal">
                        <Client :clientInfo="clientInfo"></Client>
                    </div>
                    <Teleport to="body">
                        <div class="modal modal-blur fade show" id="modal-scrollable" tabindex="-1" aria-modal="true" style="display: block;" v-if="openClientModal">
                            <ClientModal 
                            @newClient="changeClient" 
                            :invoiceId="invoiceData.id" 
                            @close="openClientModal = false" 
                            :clientsList="this.clientsList"
                            >
                            </ClientModal>
                        </div>
                    </Teleport>
                      
                    <div class="col-6 text-end" :class="invoiceMode ? 'border-custom' : ''" @click="openCompanyModal = !openCompanyModal">
                        <Company :companyInfo="companyInfo"></Company>
                    </div>                    
                    <Teleport to="body">
                        <div class="modal modal-blur fade show" id="modal-scrollable" tabindex="-1" aria-modal="true" style="display: block;" v-if="openCompanyModal">
                            <CompanyModal 
                            @newCompany="changeCompany" 
                            :invoiceId="invoiceData.id" 
                            @close="openCompanyModal = false" 
                            :companiesList="this.companiesList"
                            >
                            </CompanyModal>
                        </div>
                    </Teleport>
                     
                    <div class="col-12 my-5">
                        <h1 v-if="!invoiceMode">{{invoiceData.title}}</h1>
                        <input v-else type="text" v-model="invoiceData.title" class="border-custom">
                    </div>
                </div>
                
                <table class="table table-transparent table-responsive">
                 <thead>
                    <tr>
                        <th class="text-center"></th>
                        <th>Product</th>
                        <th class="text-center" >Qnt</th>
                        <th class="text-end" >Unit</th>
                        <th class="text-end">Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                        <invoiceItems 
                        v-for="(item, index) in invoiceData.invoice_items"
                        :item="item" 
                        :key="item.order" 
                        :index="index"
                        @remove="removeRow(index)"
                        class="invoice-item"
                        id="item.id"
                        :currency="invoiceData.currency"
                        :newItem="this.newRow"
                        ></invoiceItems>
                        <tr v-show="invoiceMode">
                            <td colspan="12">
                                <div class="text-center"><button href="#" class="btn btn-disabled" onclick="event.preventDefault()" @click="addRow">Add a New Item +</button></div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Currency</td>
                            <td class="text-end">
                                <select v-model="invoiceData.currency" class="form-select w-auto text-end">
                                    <option value="GBP">GBP</option>
                                     <option value="BRL">BRL</option>
                                    <option value="USD">USD</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Subtotal</td>
                            <td class="text-end">{{ getSubtotal }}</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="strong text-end">Vat Rate</td>
                            <td v-if="!invoiceMode" class="text-end">{{ vatRate }}%</td>
                            <td v-else class="input-group"><input v-model="vatRate" type="number" class="text-end form-control "><span class="input-group-text">%</span></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="font-weight-bold text-uppercase text-end">Total Due</td>
                            <td colspan="4" class="font-weight-bold text-end">{{ getTotal }} {{ invoiceData.currency ? invoiceData.currency : 'USD'}}</td>
                        </tr>  
                    </tbody>
                </table>
                
            </div>
            
            <div class="card-footer text-end">
                <a href="3" class="btn btn-link">Cancel</a>
                <button onclick="event.preventDefault()" @click="saveBtn(); postEvent();" class="btn btn-primary" :class="btnClicked ? 'disabled' : '' ">
                    <span class="saveSpin" v-show="btnClicked">
                        <div class="spinner-border spinner-border-sm text-light" role="status"></div>
                    </span>
                    <span>Save</span>
                </button>
            </div>            
           
        </div>
    ` ,

    components:{
        Logo,
        IssueDate,
        DueDate,
        Client,
        Company,
        InvoiceItems,
        ClientModal,
        CompanyModal,
    },

    data(){
        return {
            invoiceData: this.invoice,
            issueDate: this.invoice.issue_date,
            dueDate: this.invoice.due_date,
            vatRate: this.invoice.tax,
            invoiceMode: false,
            newRow: Object,
            openClientModal: false,
            openCompanyModal: false,
            clientsList: this.clients,
            clientInfo: this.invoice.client,
            companiesList: this.companies,
            companyInfo: this.invoice.company,
            btnClicked: false,
        }
    },

    computed: {
        getSubtotal() {
            let subtotal = 0;
            for (const item of this.invoiceData.invoice_items) {
                subtotal += item.amount;
            }
            return subtotal
        },

        getTotal() {
            let subtotal = 0;
            for (const item of this.invoiceData.invoice_items) {
                subtotal += item.amount;
            }
            let total = subtotal +(subtotal * (this.vatRate / 100));
            return total.toFixed(2)
        },

    },

    created(){
    },

    methods: {

        addRow() {
            const highestOrder = this.invoiceData.invoice_items.reduce((maxOrder, item) => {
                    return item.order > maxOrder ? item.order : maxOrder;
            }, 0);

            this.newRow = {
                id: null,
                created_at: '',
                update_at: '',
                order: highestOrder + 1,
                title: '',
                description: '',
                quantity: '',
                unit: '',
                amount: 0,
            }

            this.invoiceData.invoice_items.push(this.newRow);
        },

        removeRow(index) {
            this.invoiceData.invoice_items.splice(index, 1);
        },

        changeClient(response) {
            this.clientInfo = response;
            return this.invoiceData.client_id = response.id;
        },

        changeCompany(response) {
            this.companyInfo = response;
            return this.invoiceData.company_id = response.id;
        },

        updateIssue(newValue) {
            this.issueDate = newValue
        },

        updateDue(newValue) {
            this.dueDate = newValue
        },

        saveBtn() {
            this.btnClicked = !this.btnClicked;
        },

        showSavedResponse(status) {
            if(status === 200) {
                const toast = useToast(); // Initialize toast
                toast.success('Invoice saved successfully!', {
                    timeout: 3000,
                });
            }
        },

        postEvent: function () {
            axios.post('/invoices/'+ this.invoiceData.id + '/save',
            {
                'invoiceData': this.invoiceData,
                'vatRate': this.vatRate,
                'issueDate': this.issueDate,
                'dueDate': this.dueDate,
                'invoiceItems': this.invoiceData.invoice_items,
            }
            ).then((response) => {
                console.log(response)
                this.showSavedResponse(response.status);
                this.saveBtn();
            }).catch((error) => {
                const toast = useToast(); // Initialize toast
                toast.error('Something wrong happened! Please try again!', {
                    timeout: 3000,
                });
                this.saveBtn()
                console.log(error)
            });
        }


    }
}
