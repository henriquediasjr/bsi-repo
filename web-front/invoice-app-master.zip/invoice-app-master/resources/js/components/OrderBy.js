import { IconChevronUp, IconChevronDown } from '@tabler/icons-vue';

export default {
    props: ['name', 'value', 'dir', 'order'],
    template:`
        <a href="#order" @click="click">{{name}}</a>
        <IconChevronUp v-if="showAscIcon()"></IconChevronUp>
        <IconChevronDown v-if="showDescIcon()"></IconChevronDown>
    `,
    data() {
        return {
            page: window.location.href,
        }
    },
    methods: {
        showAscIcon: function(){
            return this.dir === 'asc' && this.order === this.value;
        },
        showDescIcon: function(){
            return this.dir === 'desc' && this.order === this.value;
        },
        click: function(){
            const newUrl = new URL(this.page)
            newUrl.searchParams.set('orderDir', (this.dir === "desc") ? 'asc' : 'desc')
            newUrl.searchParams.set('orderby', this.value)
            window.location.href = newUrl.href
        }
    },
    components: {
        IconChevronUp,
        IconChevronDown
    }
}
