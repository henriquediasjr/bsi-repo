
export default{
    props: ['companyInfo'],

    template:`
        <h3>Company</h3>
        <p class="h3">{{company.name}}</p>
        <address>
            {{company.name}}<br>
            {{company.address_number}}<br>
            {{company.address_complement}}<br>
            {{company.country}}<br>
            {{company.city}}, {{company.cep}}<br>
            {{company.email}}
        </address>
      
    `,

    data(){
        return {
        }
    },

    computed: {
        company(){
            return this.companyInfo
        }
    }
}