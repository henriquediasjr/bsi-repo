
export default{
    template:`  
         <div class="btn btn-disabled" style="width: 60%; height: 100%">
            <h2>Logo</h2>
         </div>
    `,

}