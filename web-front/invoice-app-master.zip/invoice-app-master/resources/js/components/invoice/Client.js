
export default{
    props: ['clientInfo'],

    template:`
        <h3>Client</h3>
        <p class="h3">{{client.name}}</p>
        <address>
            {{client.name}}<br>
            {{client.address_number}}<br>
            {{client.address_complement}}<br>
            {{client.country}}<br>
            {{client.city}}, {{client.cep}}<br>
            {{client.email}}
        </address>
      
    `,

    data(){
        return {
        }
    },

    computed: {
        client(){
            return this.clientInfo
        }
    }

}