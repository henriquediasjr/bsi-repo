import axios from 'axios';

export default{
    emits: ['close', 'newCompany'],
    props: ['companiesList', 'invoiceId'],
    template: `
       <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
           <div class="modal-content">
                <div class="modal-header">
                    <h2 class="mt-2">Select the company for the invoice</h2>
                    <button type="button" @click="close()" class="btn-close"></button>  
                </div>
                <div class="modal-body">
                    <table class="table card-table table-vcenter">
                        <tbody>
                            <tr 
                            v-for="(company, index) in companies" 
                            :key="index"
                            @mouseover="hover = true"
                            @mouseleave="hover = false"
                            :class="hover ? 'border-custom' :  '' "
                            class="mt-2"
                            @click="postEvent(invoiceId, company.id)"
                            >
                                <td class="col-3"><div class="div-badge"><span class="nameBadges text-center w-auto">{{initialsBadge(company.name)}}</span></div></td>
                                <td class="col-6"><span class="h2 text-nowrap">{{company.name}}</span><br>{{company.email}}</td>
                                <td class="col-3"></td>

                            </tr>
                        </tbody>
                    


                    </table>
                    <!--<div -->
                    <!---->
                    <!--&gt;-->
                        <!--<div class="row border-1">-->
                            <!--<div class="col">Logo</div>-->
                            <!--<div class="col">{{company.name}}<br>{{company.email}}</div>-->
                            <!--&lt;!&ndash;<div class="col"><button>edit</button></div>&ndash;&gt;-->
                        <!--</div>-->
                        <!---->
                    <!--</div>-->
                    
                </div>
                    
           </div>
        </div>
      
    `,

    data() {
        return {
            companies: this.companiesList,
            hover: false,
        }
    },

    methods: {
        close: function () {
            this.$emit('close')
        },

        initialsBadge: function (name) {

            var parts = name.split(' ');
            var initials = '';
            for (var i = 0; i < parts.length; i++) {
                if (parts[i].length > 0 && parts[i] !== '') {
                    initials += parts[i][0]
                }
            }
            return initials.slice(0, 2)
        },

        postEvent: function (invoiceId, companyId) {
            axios.post('/invoices/'+ invoiceId +'/company', {'companyId': companyId, 'invoiceId': invoiceId}
            ).then((response) => {
                console.log(response)
                this.callChangeCompany(response.data)
                this.close();
            }).catch(function(error) {
                console.log(error);
            });
        },

        callChangeCompany: function (response) {
            this.$emit('newCompany', response)
        }
    },
}
