
export default{
    props: ['dueDate', 'invoiceMode'],
    emits: ['updateDue'],

    template:`  
        <label class="form-label text-start">Due Date</label>
        <input
        v-if="invoiceMode"
        type="text"
        name="input-mask"
        class="form-control border-custom"
        data-mask="0000/00/00"
        data-mask-visible="true"
        placeholder="0000/00/00"
        autocomplete="off"
        v-model="dueDateInternal"
        />
        
        <div
        v-else
        type="text"
        name="input-mask"
        class="form-control text-start border-0"
        data-mask="0000/00/00"
        data-mask-visible="true"
        placeholder="0000/00/00"
        autocomplete="off"
        >{{dueDate}}</div>
    `,

    data(){
        return{
            dueDateInternal: this.dueDate,
        }
    },

    watch:{
        dueDateInternal(newValue){
            this.$emit('updateDue', newValue)
        }
    }
}