
export default {
    props: ['issueDate', 'invoiceMode'],
    emits: ['updateIssue'],

    template:`  
        <label class="form-label text-start">Issue Date</label>
        <input
        v-if="invoiceMode"
        type="text"
        name="input-mask"
        class="form-control border-custom"
        data-mask="0000/00/00"
        data-mask-visible="true"
        placeholder="0000/00/00"
        autocomplete="off"
        v-model="issueDateInternal"
        />
        
        <div
        v-else
        type="text"
        name="input-mask"
        class="form-control text-start border-0"
        data-mask="0000/00/00"
        data-mask-visible="true"
        placeholder="0000/00/00"
        autocomplete="off"
        >{{issueDate}}</div>
    `,

    data(){
        return{
            issueDateInternal: this.issueDate,
        }
    },

    watch:{
        issueDateInternal(newValue){
            this.$emit('updateIssue', newValue)
        }
    }

}