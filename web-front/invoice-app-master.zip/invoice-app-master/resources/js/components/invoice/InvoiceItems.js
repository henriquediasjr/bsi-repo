import {IconEdit, IconTrashX, IconSquareCheck} from '@tabler/icons-vue';

export default{
    props: ['item', 'currency', 'newItem', 'index'],
    components:{
        IconEdit,
        IconTrashX,
        IconSquareCheck
    },
    template:`
        <tr 
        @mouseover="hover = true"
        @mouseleave="hover = false"
        v-if="!itemMode"
        class="invoice-row"
        >
            <!--<td class="text-center">1</td>-->
            <td class="text-center">{{item.order}}</td>
            <td>
                <p class="strong mb-1">{{invoiceItem.title}}</p>
                <div class="text-secondary">{{invoiceItem.description}}</div>
            </td>
            <td class="text-center">
                {{itemQuantity}}
            </td>
            <td class="text-end">{{itemUnit}}</td>
            <td class="text-end">{{currency}} {{itemAmount}}
                <div class="text-end mt-5">
                    <IconEdit size="24" @click="itemMode = !itemMode" v-if="hover"></IconEdit>
                    <IconTrashX size="24" @click="removeRow()" v-if="hover"></IconTrashX>   
                </div>
            </td>
        </tr>
        
        <tr 
        v-else
        class="invoice-row"
        >
            <!--<td class="text-center">1</td>-->
            <td class="text-center">{{item.order}}</td>
            <td>
                <input type="text" class="form-control mb-1 border " v-model="invoiceItem.title">
                <input class="form-control text-secondary border " v-model="invoiceItem.description">
            </td>
            <td class="text-center">
                <input type="number" class="form-control text-end" v-model="itemQuantity">
            </td>
            <td class="text-end">
                <input type="number" class="form-control text-end" v-model="itemUnit">
            </td>
            <td class="text-end">
                <div class="input-group">
                    <span class="input-group-text">{{currency}}</span>
                    <input class="form-control text-end mh-60" v-model="itemAmount" readonly>
                </div>
                <div class="text-end mt-5">
                    <IconSquareCheck size="24" @click="itemMode = !itemMode"></IconSquareCheck>
                    <IconTrashX size="24" @click="removeRow()"></IconTrashX>
                </div>
            </td>            
        </tr>
        
        
        
    `,

    data() {
        return {
            invoiceItem: this.item,
            hover: false,
            itemMode: false,

        }
    },

    computed: {
        itemAmount: {
            get() {
                return this.invoiceItem.amount;
            },
            set(newValue) {
                this.invoiceItem.amount = this.itemUnit * newValue;
            }
        },
        itemUnit: {
            get() {
                return this.invoiceItem.unit;
            },
            set(newValue) {
                this.invoiceItem.unit = newValue;
            }
        },
        itemQuantity: {
            get() {
                return this.invoiceItem.quantity;
            },
            set(newValue) {
                this.invoiceItem.quantity = newValue;
            }
        }
    },

    methods: {
        quantityChanged: function () {
            this.itemAmount = this.itemQuantity; //passing the value here for the computed so the calculation happens

        },
        unityChanged: function () {
            this.itemAmount = this.itemQuantity;
        },
        removeRow: function () {
            this.$emit('remove', this.index);
            // console.log(this)
        }


    },

    watch: {
        itemQuantity(newValue) {
            this.quantityChanged();
        },
        itemUnit(newValue) {
            this.unityChanged();
        }
    },
    created() {
        if(this.newItem && this.newItem.id === null ){
            this.itemMode = !this.itemMode
        }
    }




}