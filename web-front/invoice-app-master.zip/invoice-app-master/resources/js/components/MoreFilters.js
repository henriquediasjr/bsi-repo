import FilterByStatus from "./FilterByStatus";
export default {
    props: ['status','opened'],

    template:`
     <div class="hr-text"><a href="#mais-filtros" @click="collapseMenu">{{ filterLabel }}</a></div>
        <div v-show="filterOpen">
            <FilterByStatus :status="status"></FilterByStatus>
        </div>
    `,

    data() {
        return {
            filterOpen: false,
            filterLabel: 'Mais filtros'
        }
    },

    methods: {
        collapseMenu: function () {
            this.filterOpen = !this.filterOpen;
            this.filterLabel = (this.filterOpen) ? 'Esconder filtros' : 'Mais filtros'
        }
    },

    components: {
        FilterByStatus
    },

    created: function() {
        console.log(this.status)
        // if hash we enable the filters
        if (location.hash === "#mais-filtros") {
            this.collapseMenu()
        }
        if(this.opened){
            this.collapseMenu();
        }
    }
}
