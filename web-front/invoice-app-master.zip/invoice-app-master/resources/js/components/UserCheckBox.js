export default{

    props:[
        'userId'
    ],

    template:`
        <input @change="collectId" v-model="select" class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select" :id="userId">
    `,

    data() {
        return{
            select: false
        }
    },

    methods: {
        collectId() {
            this.emitter.emit("input-id-selected", this.userId)
        }
    },

    mounted() {
        this.emitter.on('select-all-changed', (data) => {
            this.select = data
        });
    }
}