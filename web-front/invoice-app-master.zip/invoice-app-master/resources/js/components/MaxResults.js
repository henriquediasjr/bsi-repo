export default {
    props: ['limit'],

    template:`
        <div class="text-muted text-nowrap">
            Resultados por página:
            <div class="ms-2 d-inline-block">

                <select v-model="limit" name="limit" id="limit" class="form-select" @change="postEvent()">
                    <option v-for="option in options" :key="option.value" :value="option.value">
                        {{ option.value }}
                    </option>
                </select>

            </div>
        </div>
    `,

    created() {
        // console.log(this.limit)
    },

    data() {
        return {
            options: [
                { value: 10 },
                { value: 25 },
                { value: 50 },
                { value: 100 },
            ],
        }
    },

    methods: {
        postEvent: function(){
            document.forms['users'].submit()
        }
    }
}
