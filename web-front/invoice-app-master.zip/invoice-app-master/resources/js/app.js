import './bootstrap';

import Alpine from 'alpinejs';
import mitt from 'mitt';
import { createApp } from "vue";
import MoreFilters from "./components/MoreFilters.js";
import MaxResults from "./components/MaxResults";
import OrderBy from "./components/OrderBy";
import CheckBoxAll from "./components/CheckBoxAll";
import UserCheckBox from "./components/UserCheckBox";
import BulkActions from "./components/BulkActions";
import Invoice from "./components/Invoice";
import Toast from 'vue-toastification';
import 'vue-toastification/dist/index.css';

window.Alpine = Alpine;

Alpine.start();

import.meta.glob([
    '../images/**'
]);

const emitter = mitt();
const app = createApp({
    components: {
        'max-results': MaxResults,
        'more-filters': MoreFilters,
        'order-by': OrderBy,
        'checkbox-all': CheckBoxAll,
        'user-checkbox': UserCheckBox,
        'bulk-actions': BulkActions,
        'invoice': Invoice
    }
});

app.use(Toast);
app.config.globalProperties.emitter = emitter;
app.mount('#app');
