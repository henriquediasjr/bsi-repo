<?php

use App\Http\Controllers\ClientsController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['auth', 'auth.checkInactive'])->group(function () {

    Route::get('/wizard', function () {
        return view('wizard');
    })->name('wizard');

    Route::get('/', [DashboardController::class, 'index'])
        ->name('home');
    Route::get('/profile', [ProfileController::class, 'edit'])
        ->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])
        ->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])
        ->name('profile.destroy');

    Route::resource('users', UserController::class);

    Route::resource('companies', CompanyController::class);
    Route::get('companies-export', [CompanyController::class, 'export'])
        ->name('companies.export');

    Route::resource('clients', ClientsController::class);
    Route::get('clients-export', [ClientsController::class, 'export'])
        ->name('clients.export');

    Route::resource('invoices', InvoiceController::class);
    Route::get('invoices-export', [InvoiceController::class, 'export'])
        ->name('invoices.export');

    Route::post('invoices/{invoice}/client', [InvoiceController::class, 'clientChange'])
        ->name('invoices.clientChange');
    Route::post('invoices/{invoice}/company', [InvoiceController::class, 'companyChange'])
        ->name('invoices.companyChange');

    Route::post('invoices/{invoice}/save', [InvoiceController::class, 'invoiceSave'])
        ->name('invoices.invoiceSave');
});

require __DIR__.'/auth.php';
